from __future__ import annotations
from typing import Any, Mapping
_HTTPISH_TCP_PORTS = frozenset({80, 443, 3000, 5000, 5055, 8000, 8080, 8443, 9000, 10443, 11080})

def _image_repository(value: Any) -> str:
    text = str(value or '').strip().casefold()
    if not text:
        return ''
    text = text.split('@', 1)[0]
    slash = text.rfind('/')
    colon = text.rfind(':')
    if colon > slash:
        text = text[:colon]
    return text

def _httpish_published_ports(workload: Mapping[str, Any]) -> tuple[int, ...]:
    raw = workload.get('published_ports', [])
    if not isinstance(raw, list):
        return ()
    ports: set[int] = set()
    for item in raw:
        if not isinstance(item, Mapping) or str(item.get('protocol', 'tcp')).casefold() != 'tcp':
            continue
        for key in ('public_port', 'private_port'):
            value = item.get(key)
            if isinstance(value, int) and (not isinstance(value, bool)) and (value in _HTTPISH_TCP_PORTS):
                ports.add(value)
    return tuple(sorted(ports))

def connection_suggestions(workload: Mapping[str, Any]) -> tuple[dict[str, Any], ...]:
    """Return bounded declarative downstream Connection suggestions.

    The provider owns product recognition and candidate semantics. Generic Core
    only materializes these descriptors after environment/System review.
    """
    result: list[dict[str, Any]] = []
    images = workload.get('images', [])
    repositories = {_image_repository(image) for image in images if isinstance(image, str) and image.strip()} if isinstance(images, list) else set()
    image_match = any((repository.rsplit('/', 1)[-1] == 'scrypted' for repository in repositories))
    compose_service = str(workload.get('compose_service') or '').strip().casefold()
    service_match = compose_service == 'scrypted'
    if image_match or service_match:
        signal = 'container image' if image_match else 'Compose service identity'
        result.append({'adapter': 'scrypted', 'preset': 'scrypted', 'label': 'Scrypted', 'reason': f'Detected Scrypted from Portainer {signal}.', 'candidate_kind': 'scrypted', 'candidate_endpoint': 'manual://scrypted', 'candidate_confidence': 'detected', 'candidate_default_selected': True, 'candidate_label_prefix': 'Scrypted', 'suppress_if_adapter_present': 'scrypted'})
    ports = _httpish_published_ports(workload)
    if ports:
        display = ', '.join((str(port) for port in ports[:4]))
        result.append({'adapter': 'http', 'preset': 'http_service', 'label': 'HTTP(S)', 'reason': f'Portainer reports published TCP port(s) commonly used for HTTP(S): {display}.', 'candidate_kind': 'http', 'candidate_endpoint': 'manual://http', 'candidate_confidence': 'possible', 'candidate_default_selected': False, 'candidate_label_prefix': 'HTTP(S)'})
    return tuple(result)

def recursive_suggestions(observation: Mapping[str, Any]) -> tuple[dict[str, Any], ...]:
    metadata = observation.get('metadata')
    if not isinstance(metadata, Mapping):
        return ()
    workloads = metadata.get('workloads')
    if not isinstance(workloads, list):
        return ()
    output: list[dict[str, Any]] = []
    for workload in workloads:
        if not isinstance(workload, Mapping):
            continue
        environment_key = _optional_text(workload.get('environment_key'))
        workload_identity = _optional_text(workload.get('identity'))
        workload_label = _optional_text(workload.get('label'))
        if not environment_key or not workload_identity or (not workload_label):
            continue
        for suggestion in connection_suggestions(workload):
            output.append({'environment_key': environment_key, 'workload_identity': workload_identity, 'workload_label': workload_label, **suggestion})
    return tuple(output)

def generic_workload_evidence(workloads: Any, *, authoritative: bool) -> list[dict[str, Any]]:
    """Project authenticated Portainer workload rows into generic discovery evidence."""
    if not isinstance(workloads, list):
        return []
    result: list[dict[str, Any]] = []
    for workload in workloads:
        if not isinstance(workload, Mapping):
            continue
        identity = workload.get('identity')
        label = workload.get('label')
        if not isinstance(identity, str) or not identity or (not isinstance(label, str)) or (not label):
            continue
        metadata = dict(workload)
        metadata['authoritative'] = authoritative
        required_hint = workload.get('required_hint')
        if required_hint is True:
            metadata['policy_hint'] = 'required'
        elif required_hint is False:
            metadata['policy_hint'] = 'optional'
        suggestions = connection_suggestions(workload)
        if suggestions:
            metadata['connection_suggestions'] = [dict(item) for item in suggestions]
        result.append({'source': 'portainer', 'source_id': identity, 'kind': 'service', 'label': label, 'confidence': 95, 'addresses': [], 'suggested_capabilities': ['docker_workload'], 'metadata': metadata})
    return result

def _optional_text(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    text = value.strip()
    return text or None
