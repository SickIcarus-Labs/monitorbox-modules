'use strict';

// Restore the established v1 service hierarchy without creating a second
// health model. Canonical service objects remain in /api/v2/state and retain
// their individual drawers; this layer only composes how they are presented.
const servicePresentationBaseRenderSite=renderSite;
const servicePresentationBaseFindObject=findObject;
const servicePresentationBaseRenderDrawer=renderDrawer;
const SERVICE_GROUP_ID='__services__';
const nativeServiceIcons=new Set([
  'plex','homeassistant','homebridge','sonarr','radarr','qbittorrent','portainer',
  'pihole','cockpit','seerr','tautulli','lidarr','prowlarr','bazarr','sabnzbd',
  'ombi','scrob',
]);
let servicePresentationParent=null;

function servicesForSite(site){
  return(site?.objects||[]).filter(object=>object.kind==='service'&&object.retired!==true);
}

function orderedServices(services){
  return[...services].sort((a,b)=>stateRank(b.state)-stateRank(a.state)||String(a.label).localeCompare(String(b.label)));
}

function serviceGroupState(services){
  const ordered=orderedServices(services);
  return ordered.length?ordered[0].state:'unknown';
}

function serviceGroupSummary(services){
  if(!services.length)return'No services configured';
  const healthy=services.filter(service=>service.state==='healthy').length;
  const planned=services.filter(service=>service.state==='planned').length;
  const worst=orderedServices(services)[0];
  if(stateRank(worst.state)>0)return`${healthy} healthy · ${services.length-healthy} need attention · ${worst.label}: ${worst.summary}`;
  if(planned)return`${healthy} healthy · ${planned} planned`;
  return`${healthy} of ${services.length} reporting normally`;
}

function serviceHostGroups(site,services){
  const hosts=(site.objects||[]).filter(object=>object.kind==='host');
  const assigned=new Set();
  const groups=[];
  for(const host of hosts){
    const children=services.filter(service=>(service.depends_on||[]).includes(host.id));
    if(!children.length)continue;
    children.forEach(service=>assigned.add(service.id));
    groups.push({label:host.label,services:children});
  }
  const other=services.filter(service=>!assigned.has(service.id));
  if(other.length)groups.push({label:'Other',services:other});
  return groups;
}

function serviceComposeProvenance(service){
  for(const component of service?.components||[]){
    const metadata=component?.metadata||{};
    const provider=String(metadata.provider||component?.adapter||'').trim().toLowerCase();
    const project=String(metadata.compose_project||metadata.stack_name||'').trim();
    const composeService=String(metadata.compose_service||'').trim();
    const environmentKey=String(metadata.environment_key||metadata.environment_provider_id||'').trim();
    const environmentLabel=String(metadata.environment_name||metadata.environment||environmentKey).trim();
    const deployment=String(metadata.deployment_kind||'').trim().toLowerCase();
    if(provider!=='portainer'||!project||!environmentKey)continue;
    if(deployment&&deployment!=='compose')continue;
    return{
      project,
      composeService:composeService||String(service.label||'').trim(),
      environmentKey,
      environmentLabel:environmentLabel||environmentKey,
      key:`${environmentKey}\u0000${project}`,
    };
  }
  return null;
}

function servicePresentationEntries(services){
  const grouped=new Map(),plain=[];
  for(const service of services){
    const provenance=serviceComposeProvenance(service);
    if(!provenance){plain.push(service);continue;}
    let group=grouped.get(provenance.key);
    if(!group){
      group={
        key:provenance.key,
        project:provenance.project,
        environmentKey:provenance.environmentKey,
        environmentLabel:provenance.environmentLabel,
        services:[],
      };
      grouped.set(provenance.key,group);
    }
    group.services.push(service);
  }
  const stackGroups=[],singletons=[...plain];
  for(const group of grouped.values()){
    if(group.services.length<2){singletons.push(...group.services);continue;}
    group.state=serviceGroupState(group.services);
    stackGroups.push(group);
  }
  const projectCounts=new Map();
  for(const group of stackGroups)projectCounts.set(group.project,(projectCounts.get(group.project)||0)+1);
  const entries=stackGroups.map(group=>({
    kind:'stack',
    state:group.state,
    label:projectCounts.get(group.project)>1?`${group.project} · ${group.environmentLabel}`:group.project,
    group,
  }));
  entries.push(...singletons.map(service=>({kind:'service',state:service.state,label:service.label,service})));
  return entries.sort((a,b)=>stateRank(b.state)-stateRank(a.state)||String(a.label).localeCompare(String(b.label)));
}

function serviceGroupObject(site){
  const services=servicesForSite(site);
  const state=serviceGroupState(services);
  return{
    id:SERVICE_GROUP_ID,
    label:'Services',
    kind:'service_group',
    state,
    underlying_state:state,
    summary:serviceGroupSummary(services),
    services,
    components:[],
    front_page:true,
    health_participant:false,
  };
}

findObject=function(siteId,objectId){
  if(objectId!==SERVICE_GROUP_ID)return servicePresentationBaseFindObject(siteId,objectId);
  const site=app.state?.sites?.find(item=>item.id===siteId);
  return{site,object:site?serviceGroupObject(site):undefined};
};

function serviceDirectoryNames(services){
  return servicePresentationEntries(services).map(entry=>entry.kind==='stack'?`${entry.label} (${entry.group.services.length})`:entry.service.label).join(' · ');
}

function serviceDirectory(site,services){
  return serviceHostGroups(site,services).map(group=>`<span class="service-directory-group"><b>${esc(group.label)}</b><small>${esc(serviceDirectoryNames(group.services))}</small></span>`).join('');
}

function renderServiceSummaryCard(site){
  const services=servicesForSite(site);
  if(!services.length)return'';
  const state=serviceGroupState(services),summary=serviceGroupSummary(services);
  return`<button class="card services-summary-card ${esc(state)}" data-site="${esc(site.id)}" data-object="${SERVICE_GROUP_ID}" type="button"><span class="card-top"><span><h3>Services</h3><span class="card-type">Service directory</span></span>${pill(state)}</span><span class="card-summary">${esc(summary)}</span>${stateRank(state)===0?`<span class="service-directory">${serviceDirectory(site,services)}</span>`:''}</button>`;
}

renderSite=function(site){
  const original=site.objects||[];
  const services=servicesForSite(site);
  site.objects=original.filter(object=>object.kind!=='service');
  let html;
  try{html=servicePresentationBaseRenderSite(site);}
  finally{site.objects=original;}
  if(!services.length)return html;
  const marker='</div></section>';
  const index=html.lastIndexOf(marker);
  if(index<0)return html;
  return`${html.slice(0,index)}${renderServiceSummaryCard(site)}${html.slice(index)}`;
};

function serviceIcon(service){
  const icon=nativeServiceIcons.has(service.icon)?service.icon:null;
  const letters=String(service.label||'').split(/\s+/).filter(Boolean).map(word=>word[0]).join('').slice(0,2).toUpperCase()||'S';
  const body=icon?`<img src="/static/icons/${esc(icon)}.svg" alt="">`:`<span>${esc(letters)}</span>`;
  if(service.presentation_url)return`<a class="service-icon icon-outbound" href="${esc(service.presentation_url)}" target="_blank" rel="noopener" aria-label="Open ${esc(service.label)}">${body}<i>↗</i></a>`;
  return`<span class="service-icon" aria-hidden="true">${body}</span>`;
}

function serviceRow(site,service,parent){
  const component=(service.components||[]).find(item=>item.enabled&&item.state!=='healthy')||(service.components||[]).find(item=>item.enabled);
  const detail=component?.summary||service.summary||'Status unavailable';
  return`<div class="service-navigation-row">${serviceIcon(service)}<button class="component-row service-navigation-button" data-service-object="${esc(service.id)}" data-service-parent="${esc(parent)}" type="button"><span><strong>${esc(service.label)}</strong><small>${esc(detail)}</small></span>${pill(service.state)}</button></div>`;
}

function serviceRows(site,services,parent){
  return orderedServices(services).map(service=>serviceRow(site,service,parent)).join('');
}

function serviceStackRow(site,entry,parent){
  const group=entry.group;
  const count=group.services.length;
  const attention=stateRank(entry.state)>0;
  const serviceNames=orderedServices(group.services).map(service=>service.label).join(' · ');
  return`<details class="service-compose-group ${esc(entry.state)}" data-compose-stack="${esc(group.key)}"${attention?' open':''}><summary class="service-compose-summary"><span class="service-compose-copy"><strong>${esc(entry.label)}</strong><small>${count} services · ${esc(group.environmentLabel)} · ${esc(serviceNames)}</small></span>${pill(entry.state)}</summary><div class="service-compose-members service-list">${serviceRows(site,group.services,parent)}</div></details>`;
}

function servicePresentationRows(site,services,parent){
  return servicePresentationEntries(services).map(entry=>entry.kind==='stack'?serviceStackRow(site,entry,parent):serviceRow(site,entry.service,parent)).join('');
}

function bindServiceNavigation(site){
  document.querySelectorAll('[data-service-object]').forEach(node=>node.addEventListener('click',()=>{
    const parentId=node.dataset.serviceParent||SERVICE_GROUP_ID;
    const parent=parentId===SERVICE_GROUP_ID?serviceGroupObject(site):(site.objects||[]).find(item=>item.id===parentId);
    servicePresentationParent=parent?{siteId:site.id,objectId:parent.id,label:parent.label}:null;
    openDrawer(site.id,node.dataset.serviceObject);
  }));
  document.querySelector('[data-service-back]')?.addEventListener('click',()=>{
    const parent=servicePresentationParent;
    servicePresentationParent=null;
    if(parent)openDrawer(parent.siteId,parent.objectId);
  });
}

function renderServiceGroupDrawer(site,object){
  $('#drawer-eyebrow').textContent=`${site.label} · service directory`;
  $('#drawer-title').textContent='Services';
  $('#drawer-state').className=`state-pill ${object.state}`;
  $('#drawer-state').textContent=stateLabel(object.state);
  const groups=serviceHostGroups(site,object.services);
  $('#drawer-body').innerHTML=`<section class="detail-section"><div class="detail-state"><div><h3>Current state</h3><strong>${esc(stateLabel(object.state))}</strong><p>${esc(object.summary)}</p></div>${pill(object.state)}</div></section>${groups.map(group=>`<section class="detail-section"><h3>${esc(group.label)}</h3><div class="service-list">${servicePresentationRows(site,group.services,SERVICE_GROUP_ID)}</div></section>`).join('')}`;
  bindServiceNavigation(site);
}

function appendHostedServices(site,host){
  const hosted=servicesForSite(site).filter(service=>(service.depends_on||[]).includes(host.id));
  if(!hosted.length)return;
  $('#drawer-body').insertAdjacentHTML('beforeend',`<section class="detail-section"><h3>Services</h3><div class="service-list">${servicePresentationRows(site,hosted,host.id)}</div></section>`);
  bindServiceNavigation(site);
}

function prependServiceBack(site,service){
  const parent=servicePresentationParent;
  if(!parent||parent.siteId!==site.id)return;
  $('#drawer-body').insertAdjacentHTML('afterbegin',`<div class="service-back-row"><button class="button secondary" data-service-back type="button">← ${esc(parent.label)}</button><span>${esc(service.label)}</span></div>`);
  bindServiceNavigation(site);
}

renderDrawer=function(){
  if(!app.selected||!app.state)return servicePresentationBaseRenderDrawer();
  const {site,object}=findObject(app.selected.siteId,app.selected.objectId);
  if(!site||!object)return servicePresentationBaseRenderDrawer();
  if(object.kind==='service_group')return renderServiceGroupDrawer(site,object);
  servicePresentationBaseRenderDrawer();
  if(object.kind==='host')appendHostedServices(site,object);
  if(object.kind==='service')prependServiceBack(site,object);
};

// UI 1.0.1 build 6: compose the Service Directory from canonical services plus
// provider-native Portainer workload truth. This is presentation-only: provider
// workload rows are never persisted as canonical health objects.
const PROVIDER_WORKLOAD_PREFIX='__provider_workload__:';
const providerHierarchyBaseFindObject=findObject;
const providerHierarchyBaseRenderDrawer=renderDrawer;

function providerNormalizeToken(value){
  return String(value||'').trim().toLowerCase().replace(/[^a-z0-9]+/g,'');
}

function providerExactAddress(value){
  const text=String(value||'').trim().toLowerCase();
  if(!text||text.includes('/')||text==='localhost')return'';
  return text.replace(/^\[|\]$/g,'');
}

function providerUrlHost(value){
  const text=String(value||'').trim();
  if(!text||text.toLowerCase().startsWith('unix://'))return'';
  try{return String(new URL(text).hostname||'').trim().toLowerCase();}
  catch(_error){
    const match=text.match(/^[a-z][a-z0-9+.-]*:\/\/\[?([^\]/:]+)\]?/i);
    return match?String(match[1]).trim().toLowerCase():'';
  }
}

function portainerInventoryWorkloads(site){
  const byIdentity=new Map();
  for(const object of site?.objects||[]){
    for(const component of object?.components||[]){
      const metadata=component?.metadata||{};
      if(String(metadata.provider||'').trim().toLowerCase()!=='portainer')continue;
      if(metadata.authoritative!==true||!Array.isArray(metadata.workloads))continue;
      for(const workload of metadata.workloads){
        if(!workload||typeof workload!=='object')continue;
        const identity=String(workload.identity||'').trim();
        if(identity)byIdentity.set(identity,workload);
      }
    }
  }
  return[...byIdentity.values()];
}

function providerWorkloadEnvironmentHosts(workload){
  const hosts=new Set();
  const direct=providerUrlHost(workload?.environment_url);
  if(direct)hosts.add(direct);
  for(const endpoint of workload?.service_endpoints||[]){
    const host=providerExactAddress(endpoint?.host)||String(endpoint?.host||'').trim().toLowerCase();
    if(host)hosts.add(host);
  }
  return hosts;
}

function providerEnvironmentOwners(site,workloads){
  const localHosts=(site?.objects||[]).filter(object=>
    ['host','appliance'].includes(String(object?.kind||''))&&providerExactAddress(object?.address)
  );
  const owners=new Map();
  // A local unix:// Portainer environment has no network hostname. Its authenticated
  // controller-self row is nevertheless strong provider-native proof that the
  // inventory component's canonical Portainer service and its host own that
  // environment. This is identity/provenance, not label inference.
  for(const object of site?.objects||[]){
    const ownerHost=localHosts.find(host=>(object?.depends_on||[]).includes(host.id));
    if(!ownerHost)continue;
    for(const component of object?.components||[]){
      const metadata=component?.metadata||{};
      if(String(metadata.provider||'').trim().toLowerCase()!=='portainer'||metadata.authoritative!==true)continue;
      for(const workload of metadata.workloads||[]){
        if(workload?.discovery_suppression_reason!=='authenticated_portainer_controller')continue;
        const environmentKey=String(workload.environment_key||'').trim();
        if(environmentKey)owners.set(environmentKey,ownerHost);
      }
    }
  }
  const candidates=new Map();
  for(const workload of workloads){
    const environmentKey=String(workload?.environment_key||'').trim();
    if(!environmentKey)continue;
    let set=candidates.get(environmentKey);
    if(!set){set=new Set();candidates.set(environmentKey,set);}
    for(const host of providerWorkloadEnvironmentHosts(workload))set.add(host);
  }
  for(const [environmentKey,addresses] of candidates){
    if(owners.has(environmentKey))continue;
    const matches=localHosts.filter(host=>addresses.has(providerExactAddress(host.address)));
    if(matches.length===1)owners.set(environmentKey,matches[0]);
  }
  return owners;
}

function providerWorkloadRuntime(workload){
  let starting=false;
  const containers=Array.isArray(workload?.containers)?workload.containers:[];
  for(const container of containers){
    const state=String(container?.state||'unknown').trim().toLowerCase();
    const health=String(container?.health||'').trim().toLowerCase();
    const lifecycle=container?.lifecycle&&typeof container.lifecycle==='object'?container.lifecycle:{};
    if(
      lifecycle.confirmed_anomaly===true||health==='unhealthy'||
      state==='restarting'||state==='dead'
    ){
      const kind=lifecycle.crash_loop===true?'crash loop':
        lifecycle.oom_killed===true?'OOM kill':
        lifecycle.nonzero_exit===true?'non-zero exit':
        health==='unhealthy'?'unhealthy container':state;
      return{state:'failed',neutral:false,summary:`Docker runtime problem: ${kind}`};
    }
    if(health==='starting'||state==='created'||state==='starting')starting=true;
  }
  if(starting)return{state:'degraded',neutral:false,summary:'Docker workload is starting'};
  if(containers.length&&containers.every(container=>String(container?.state||'').trim().toLowerCase()==='running')){
    return{state:'healthy',neutral:false,summary:'Docker workload running'};
  }
  return{
    state:'unknown',
    neutral:true,
    summary:'Docker workload is not running; expected-state intent is not configured',
  };
}

function providerWorkloadObject(workload,host){
  const runtime=providerWorkloadRuntime(workload);
  const identity=String(workload.identity||'');
  const label=String(workload.compose_service||workload.label||identity||'Docker workload');
  const containers=(workload.containers||[]).filter(container=>container&&typeof container==='object');
  return{
    id:`${PROVIDER_WORKLOAD_PREFIX}${identity}`,
    label,
    kind:'provider_workload',
    state:runtime.state,
    underlying_state:runtime.state,
    summary:runtime.summary,
    retired:false,
    address:host?.address||'',
    presentation_url:null,
    icon:null,
    depends_on:host?[host.id]:[],
    components:containers.map((container,index)=>({
      id:`provider-container-${index}`,
      label:String(container.name||container.provider_id||`Container ${index+1}`),
      adapter:'portainer',
      enabled:true,
      state:providerWorkloadRuntime({containers:[container]}).state,
      summary:`${String(container.state||'unknown')}${container.health?` · ${container.health}`:''}`,
      metadata:{provider:'portainer',container,workload_identity:identity},
    })),
    health_participant:false,
    front_page:false,
    actions:[],
    _provider_workload:workload,
    _provider_health_neutral:runtime.neutral,
  };
}

function canonicalProviderKey(service,host){
  const hostId=String(host?.id||'');
  const id=String(service?.id||'');
  if(hostId&&id.startsWith(`${hostId}_`)){
    const suffix=providerNormalizeToken(id.slice(hostId.length+1));
    if(suffix)return suffix;
  }
  const label=providerNormalizeToken(service?.label);
  return label||providerNormalizeToken(id);
}

function providerWorkloadKey(workload){
  return providerNormalizeToken(workload?.compose_service||workload?.label||'');
}

function providerDirectIdentity(service){
  for(const component of service?.components||[]){
    const metadata=component?.metadata||{};
    if(String(metadata.provider||component?.adapter||'').trim().toLowerCase()!=='portainer')continue;
    const identity=String(metadata.identity||metadata.workload_identity||'').trim();
    if(identity)return identity;
  }
  return'';
}

function providerPresentationModel(site){
  const canonical=(site?.objects||[]).filter(object=>object.kind==='service'&&object.retired!==true);
  const inventory=portainerInventoryWorkloads(site);
  const owners=providerEnvironmentOwners(site,inventory);
  const local=inventory.filter(workload=>{
    const environmentKey=String(workload?.environment_key||'').trim();
    return owners.has(environmentKey)&&workload?.ignored!==true&&workload?.discovery_actionable!==false;
  });
  const byIdentity=new Map(local.map(workload=>[String(workload.identity||''),workload]));
  const byEnvironment=new Map();
  for(const workload of local){
    const key=String(workload.environment_key||'');
    const list=byEnvironment.get(key)||[];
    list.push(workload);byEnvironment.set(key,list);
  }
  const matched=new Set();
  const services=[];
  for(const service of canonical){
    let workload=null;
    const direct=providerDirectIdentity(service);
    if(direct&&byIdentity.has(direct))workload=byIdentity.get(direct);
    if(!workload){
      const host=(site?.objects||[]).find(object=>(service.depends_on||[]).includes(object.id)&&['host','appliance'].includes(object.kind));
      if(host){
        const environmentKeys=[...owners.entries()].filter(([,owner])=>owner.id===host.id).map(([key])=>key);
        const desired=canonicalProviderKey(service,host);
        const candidates=environmentKeys.flatMap(key=>byEnvironment.get(key)||[]).filter(row=>providerWorkloadKey(row)===desired);
        if(candidates.length===1)workload=candidates[0];
      }
    }
    if(workload){
      matched.add(String(workload.identity||''));
      services.push({...service,_provider_workload:workload});
    }else services.push(service);
  }
  for(const workload of local){
    const identity=String(workload.identity||'');
    if(matched.has(identity))continue;
    const host=owners.get(String(workload.environment_key||''));
    services.push(providerWorkloadObject(workload,host));
  }
  return{services,inventory,owners};
}

servicesForSite=function(site){
  return providerPresentationModel(site).services;
};

serviceHostGroups=function(site,services){
  const hosts=(site.objects||[]).filter(object=>['host','appliance'].includes(object.kind));
  const assigned=new Set();
  const groups=[];
  for(const host of hosts){
    const children=services.filter(service=>(service.depends_on||[]).includes(host.id));
    if(!children.length)continue;
    children.forEach(service=>assigned.add(service.id));
    groups.push({label:host.label,services:children});
  }
  const other=services.filter(service=>!assigned.has(service.id));
  if(other.length)groups.push({label:'Other',services:other});
  return groups;
};

serviceComposeProvenance=function(service){
  const workload=service?._provider_workload;
  if(workload&&typeof workload==='object'){
    const project=String(workload.compose_project||'').trim();
    const environmentKey=String(workload.environment_key||'').trim();
    if(project&&environmentKey){
      return{
        project,
        composeService:String(workload.compose_service||service.label||'').trim(),
        environmentKey,
        environmentLabel:String(workload.environment_name||environmentKey).trim(),
        key:`${environmentKey}\u0000${project}`,
      };
    }
  }
  for(const component of service?.components||[]){
    const metadata=component?.metadata||{};
    const provider=String(metadata.provider||component?.adapter||'').trim().toLowerCase();
    const project=String(metadata.compose_project||metadata.stack_name||'').trim();
    const composeService=String(metadata.compose_service||'').trim();
    const environmentKey=String(metadata.environment_key||metadata.environment_provider_id||'').trim();
    const environmentLabel=String(metadata.environment_name||metadata.environment||environmentKey).trim();
    const deployment=String(metadata.deployment_kind||'').trim().toLowerCase();
    if(provider!=='portainer'||!project||!environmentKey)continue;
    if(deployment&&deployment!=='compose')continue;
    return{project,composeService:composeService||String(service.label||'').trim(),environmentKey,environmentLabel:environmentLabel||environmentKey,key:`${environmentKey}\u0000${project}`};
  }
  return null;
};

function providerAggregateServices(services){
  const participating=services.filter(service=>service?._provider_health_neutral!==true);
  return participating.length?participating:services;
}

serviceGroupState=function(services){
  const relevant=providerAggregateServices(services);
  const ordered=orderedServices(relevant);
  return ordered.length?ordered[0].state:'unknown';
};

serviceGroupSummary=function(services){
  if(!services.length)return'No services configured';
  const relevant=providerAggregateServices(services);
  const state=serviceGroupState(services);
  const healthy=services.filter(service=>service.state==='healthy').length;
  const neutral=services.filter(service=>service._provider_health_neutral===true).length;
  if(stateRank(state)>0){
    const worst=orderedServices(relevant)[0];
    return`${healthy} healthy · ${services.length-healthy-neutral} need attention${neutral?` · ${neutral} intent-neutral`:''} · ${worst.label}: ${worst.summary}`;
  }
  return`${healthy} healthy${neutral?` · ${neutral} intent-neutral`:''} · ${services.length} visible service/workload(s)`;
};

serviceGroupObject=function(site){
  const services=servicesForSite(site);
  const state=serviceGroupState(services);
  return{
    id:SERVICE_GROUP_ID,label:'Services',kind:'service_group',state,underlying_state:state,
    summary:serviceGroupSummary(services),services,components:[],front_page:true,health_participant:false,
  };
};

function providerWorkloadFromObjectId(site,objectId){
  if(!String(objectId||'').startsWith(PROVIDER_WORKLOAD_PREFIX))return null;
  const identity=String(objectId).slice(PROVIDER_WORKLOAD_PREFIX.length);
  const model=providerPresentationModel(site);
  return model.services.find(service=>service.kind==='provider_workload'&&String(service._provider_workload?.identity||'')===identity)||null;
}

findObject=function(siteId,objectId){
  const site=app.state?.sites?.find(item=>item.id===siteId);
  const providerObject=site?providerWorkloadFromObjectId(site,objectId):null;
  if(providerObject)return{site,object:providerObject};
  return providerHierarchyBaseFindObject(siteId,objectId);
};

function renderProviderWorkloadDrawer(site,object){
  const workload=object._provider_workload||{};
  $('#drawer-eyebrow').textContent=`${site.label} · Docker workload`;
  $('#drawer-title').textContent=object.label;
  $('#drawer-state').className=`state-pill ${object.state}`;
  $('#drawer-state').textContent=stateLabel(object.state);
  const identity=String(workload.identity||'');
  const provenance=[workload.environment_name,workload.compose_project&&`Stack ${workload.compose_project}`,workload.compose_service&&`Service ${workload.compose_service}`].filter(Boolean).join(' · ');
  const containers=(workload.containers||[]).map(container=>{
    const runtime=providerWorkloadRuntime({containers:[container]});
    const name=String(container?.name||container?.provider_id||'Container');
    const detail=[container?.state,container?.health,container?.lifecycle?.restart_count!=null?`restarts ${container.lifecycle.restart_count}`:''].filter(Boolean).join(' · ');
    return`<div class="component-row"><span><strong>${esc(name)}</strong><small>${esc(detail||'Runtime state unavailable')}</small></span>${pill(runtime.state)}</div>`;
  }).join('');
  $('#drawer-body').innerHTML=`<section class="detail-section"><div class="detail-state"><div><h3>Current state</h3><strong>${esc(stateLabel(object.state))}</strong><p>${esc(object.summary)}</p></div>${pill(object.state)}</div></section><section class="detail-section"><h3>Portainer provenance</h3><p>${esc(provenance||'Portainer workload')}</p><small>${esc(identity)}</small></section><section class="detail-section"><h3>Containers</h3>${containers||'<p>No container rows available.</p>'}</section>`;
};

renderDrawer=function(){
  if(app.selected&&app.state){
    const {site,object}=findObject(app.selected.siteId,app.selected.objectId);
    if(site&&object?.kind==='provider_workload')return renderProviderWorkloadDrawer(site,object);
  }
  return providerHierarchyBaseRenderDrawer();
};

// UI 1.0.1 build 6 presentation polish over the provider-backed hierarchy.
// Prefer the canonical application label for a Compose parent when exactly one
// canonical service participates; otherwise preserve provider project identity.
const providerHierarchyBuild6BaseComposeProvenance=serviceComposeProvenance;
const providerHierarchyBuild6BasePresentationEntries=servicePresentationEntries;

serviceComposeProvenance=function(service){
  const provenance=providerHierarchyBuild6BaseComposeProvenance(service);
  const workload=service?._provider_workload;
  if(provenance&&workload&&typeof workload==='object'){
    provenance.environmentLabel=String(
      workload.environment_name||workload.environment||provenance.environmentLabel||provenance.environmentKey
    ).trim()||provenance.environmentKey;
  }
  return provenance;
};

function providerStackDisplayBase(entry){
  const canonical=entry.group.services.filter(service=>service.kind==='service');
  if(canonical.length===1&&String(canonical[0].label||'').trim()){
    return String(canonical[0].label).trim();
  }
  return String(entry.group.project||entry.label||'Docker stack').trim()||'Docker stack';
}

servicePresentationEntries=function(services){
  const entries=providerHierarchyBuild6BasePresentationEntries(services);
  const stacks=entries.filter(entry=>entry.kind==='stack');
  const preferred=new Map();
  const counts=new Map();
  for(const entry of stacks){
    const label=providerStackDisplayBase(entry);
    preferred.set(entry,label);
    const key=label.toLocaleLowerCase();
    counts.set(key,(counts.get(key)||0)+1);
  }
  for(const entry of stacks){
    const label=preferred.get(entry);
    const duplicate=(counts.get(label.toLocaleLowerCase())||0)>1;
    entry.label=duplicate?`${label} · ${entry.group.environmentLabel}`:label;
  }
  return entries.sort((a,b)=>stateRank(b.state)-stateRank(a.state)||String(a.label).localeCompare(String(b.label)));
};
