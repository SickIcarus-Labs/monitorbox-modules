"""Factory MonitorBox UI module package.

The normal application UI is owned by this independently identified first-party module.
Core admits and invokes the declared entrypoint without importing normal UI implementation
code. Factory packaging remains the bootstrap/recovery seed for later managed lifecycle work.
"""
from __future__ import annotations
from aiohttp import web
from monitorbox.v2.plugin_api.module_runtime import ModuleManifest
MODULE_ID = 'com.sickicarus.monitorbox.ui'
MODULE_VERSION = '1.0.0'
MODULE_BUILD = 2
MODULE_MANIFEST = ModuleManifest(module_id=MODULE_ID, display_name='MonitorBox UI', version=MODULE_VERSION, build=MODULE_BUILD, module_type='ui', entrypoints={'webui': '_mbmod_com_sickicarus_monitorbox_ui_v1_0_0_b2_0f1c91e64b:install'}, requires_core='>=2.2.2 <3.0.0', requires_runtime_api='>=1 <2', state_schema=1, publisher_id='com.sickicarus', lifecycle_policy='required')

def install(app: web.Application) -> None:
    """Install the normal MonitorBox application UI into an admitted host app."""
    from .application import install as install_application
    install_application(app)
__all__ = ['MODULE_BUILD', 'MODULE_ID', 'MODULE_MANIFEST', 'MODULE_VERSION', 'install']
