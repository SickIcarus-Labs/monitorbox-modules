from __future__ import annotations
import re
from html import escape as html_escape
from importlib.resources import files
from aiohttp import web
from monitorbox.v2.build_info import current_build_identity
ASSETS = {'dashboard.css': 'text/css; charset=utf-8', 'service-presentation.css': 'text/css; charset=utf-8', 'v1-parity.css': 'text/css; charset=utf-8', 'v1-detail-parity.css': 'text/css; charset=utf-8', 'v1-beta-polish.css': 'text/css; charset=utf-8', 'v1-beta-hotfix.css': 'text/css; charset=utf-8', 'global-debug.css': 'text/css; charset=utf-8', 'v22-shell.css': 'text/css; charset=utf-8', 'modules.css': 'text/css; charset=utf-8', 'dashboard.js': 'text/javascript; charset=utf-8', 'conceptual-presentation.js': 'text/javascript; charset=utf-8', 'service-presentation.js': 'text/javascript; charset=utf-8', 'v1-parity.js': 'text/javascript; charset=utf-8', 'v1-detail-parity.js': 'text/javascript; charset=utf-8', 'v1-global-diagnostics.js': 'text/javascript; charset=utf-8', 'v1-beta-polish.js': 'text/javascript; charset=utf-8', 'v1-beta-hotfix.js': 'text/javascript; charset=utf-8', 'global-debug.js': 'text/javascript; charset=utf-8', 'operation-progress.js': 'text/javascript; charset=utf-8', 'live-ping.js': 'text/javascript; charset=utf-8', 'live-telemetry.js': 'text/javascript; charset=utf-8', 'dashboard-widgets.js': 'text/javascript; charset=utf-8', 'policy-ui.js': 'text/javascript; charset=utf-8', 'quick-add.js': 'text/javascript; charset=utf-8', 'v22-shell.js': 'text/javascript; charset=utf-8', 'workspace-state.js': 'text/javascript; charset=utf-8', 'workspace-finish.js': 'text/javascript; charset=utf-8', 'discovery-v22.js': 'text/javascript; charset=utf-8', 'advanced-v22-polish.js': 'text/javascript; charset=utf-8', 'advanced-dirty-state.js': 'text/javascript; charset=utf-8', 'http-v22-polish.js': 'text/javascript; charset=utf-8', 'settings-v22-shell.js': 'text/javascript; charset=utf-8', 'followup-beta-polish.js': 'text/javascript; charset=utf-8', 'onboarding-v22-acceptance.js': 'text/javascript; charset=utf-8', 'modules.js': 'text/javascript; charset=utf-8'}
SERVICE_ICON_RE = re.compile('^[a-z0-9_-]+\\.svg$')
_ADVANCED_POLISH_SCRIPT = '<script src="/static/advanced-v22-polish.js" defer></script>'
_ADVANCED_DIRTY_STATE_SCRIPT = '<script src="/static/advanced-dirty-state.js" defer></script>'
_HTTP_POLISH_SCRIPT = '<script src="/static/http-v22-polish.js" defer></script>'
_SETTINGS_SHELL_SCRIPT = '<script src="/static/settings-v22-shell.js" defer></script>'
_FOLLOWUP_BETA_POLISH_SCRIPT = '<script src="/static/followup-beta-polish.js" defer></script>'
_ONBOARDING_ACCEPTANCE_SCRIPT = '<script src="/static/onboarding-v22-acceptance.js" defer></script>'

def _resource(name: str):
    return files('_mbmod_com_sickicarus_monitorbox_ui_v1_0_0_b2_0f1c91e64b.static').joinpath(name)

def _service_icon_resource(name: str):
    if not SERVICE_ICON_RE.fullmatch(name):
        return None
    resource = files('monitorbox').joinpath('static', 'icons', name)
    return resource if resource.is_file() else None

@web.middleware
async def v22_settings_presentation(request: web.Request, handler):
    """Layer 2.2 operator presentation onto established settings editors safely.

    Descendant settings editors retain their existing canonical engines and local
    controls. A shared presentation-only shell supplies consistent product/site
    identity and a dashboard escape in live mode; Setup Draft keeps those anchors
    inside Configuration until Finish. Route-specific polish remains additive.
    """
    response = await handler(request)
    if isinstance(response, web.Response) and response.content_type == 'text/html' and response.body:
        markup = response.text
        scripts: list[str] = []
        if request.path == '/settings' or request.path.startswith('/settings/'):
            scripts.append(_FOLLOWUP_BETA_POLISH_SCRIPT)
        if request.path.startswith('/settings/'):
            scripts.append(_SETTINGS_SHELL_SCRIPT)
        if request.path == '/settings/advanced':
            scripts.extend((_ADVANCED_POLISH_SCRIPT, _ADVANCED_DIRTY_STATE_SCRIPT))
        elif request.path == '/settings/quick-add':
            scripts.append(_HTTP_POLISH_SCRIPT)
        if request.path in {'/settings/quick-add', '/settings/advanced/rerun-first-launch'}:
            scripts.append(_ONBOARDING_ACCEPTANCE_SCRIPT)
        if scripts and '</body>' in markup:
            missing = [script for script in scripts if script not in markup]
            if missing:
                response.text = markup.replace('</body>', ''.join(missing) + '</body>')
    return response

async def dashboard(_: web.Request) -> web.Response:
    identity = current_build_identity()
    markup = _resource('dashboard.html').read_text(encoding='utf-8')
    markup = markup.replace('__MONITORBOX_BUILD_LABEL__', html_escape(identity.display))
    return web.Response(text=markup, content_type='text/html', charset='utf-8', headers={'Cache-Control': 'no-cache'})

async def modules(_: web.Request) -> web.Response:
    identity = current_build_identity()
    markup = _resource('modules.html').read_text(encoding='utf-8')
    markup = markup.replace('__MONITORBOX_BUILD_LABEL__', html_escape(identity.display))
    return web.Response(text=markup, content_type='text/html', charset='utf-8', headers={'Cache-Control': 'no-cache'})

async def build_identity(_: web.Request) -> web.Response:
    return web.json_response(current_build_identity().as_dict())

async def asset(request: web.Request) -> web.Response:
    name = request.match_info['name']
    content_type = ASSETS.get(name)
    if content_type is None:
        raise web.HTTPNotFound()
    media_type, _, charset = content_type.partition('; charset=')
    return web.Response(text=_resource(name).read_text(encoding='utf-8'), content_type=media_type, charset=charset or None, headers={'Cache-Control': 'no-cache'})

async def service_icon(request: web.Request) -> web.Response:
    resource = _service_icon_resource(request.match_info['name'])
    if resource is None:
        raise web.HTTPNotFound()
    return web.Response(body=resource.read_bytes(), content_type='image/svg+xml', headers={'Cache-Control': 'public, max-age=300'})

def install(app: web.Application) -> None:
    app.middlewares.append(v22_settings_presentation)
    app.router.add_get('/', dashboard)
    app.router.add_get('/modules', modules)
    app.router.add_get('/api/v2/build', build_identity)
    app.router.add_get('/static/icons/{name}', service_icon)
    app.router.add_get('/static/{name}', asset)
