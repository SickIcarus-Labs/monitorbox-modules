"""Packaged MonitorBox v2 dashboard assets."""
