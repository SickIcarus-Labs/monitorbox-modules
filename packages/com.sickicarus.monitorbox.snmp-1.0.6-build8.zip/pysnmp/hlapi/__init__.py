"""MonitorBox zipimport compatibility shim for vendored PySNMP namespace."""
