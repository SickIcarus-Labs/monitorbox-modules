"""Managed MonitorBox UI 1.1.1 build 9 composed over the certified factory UI seed."""

from importlib.resources import files

from aiohttp import web
from monitorbox.v2.modules.ui import (
    MODULE_BUILD as FACTORY_BUILD,
    MODULE_ID as FACTORY_ID,
    MODULE_VERSION as FACTORY_VERSION,
)
from monitorbox.v2.modules.ui import application as factory

_EXPECTED = ('com.sickicarus.monitorbox.ui', '1.0.0', 2)
if (FACTORY_ID, FACTORY_VERSION, FACTORY_BUILD) != _EXPECTED:
    raise ImportError(
        "managed UI 1.1.1 build 9 requires the certified MonitorBox 2.3 factory UI build 2 seed"
    )

_OVERRIDE_TYPES = {
    "discovery-v22.js": "text/javascript",
    "endpoint-prefill-v22.js": "text/javascript",
    "service-presentation.js": "text/javascript",
    "service-presentation.css": "text/css",
    "discovery-presentation.css": "text/css",
    "discovery-coverage.js": "text/javascript",
    "discovery-coverage.css": "text/css",
    "network-traffic-presentation.js": "text/javascript",
    "service-hierarchy-interactions.js": "text/javascript",
}
_ENDPOINT_PREFILL_SCRIPT = '<script src="/static/endpoint-prefill-v22.js" defer></script>'
_DISCOVERY_PRESENTATION_STYLESHEET = '<link rel="stylesheet" href="/static/discovery-presentation.css">'
_DISCOVERY_COVERAGE_STYLESHEET = '<link rel="stylesheet" href="/static/discovery-coverage.css">'
_DISCOVERY_COVERAGE_SCRIPT = '<script src="/static/discovery-coverage.js" defer></script>'
_NETWORK_TRAFFIC_SCRIPT = '<script src="/static/network-traffic-presentation.js" defer></script>'
_SERVICE_HIERARCHY_INTERACTIONS_SCRIPT = '<script src="/static/service-hierarchy-interactions.js" defer></script>'
_DISCOVERY_PRESENTATION_PATHS = frozenset(("/settings/quick-add", "/settings/discover"))


def _override_resource(name):
    return files(__package__).joinpath("assets", name)


@web.middleware
async def managed_ui_presentation(request, handler):
    response = await handler(request)
    if not (
        isinstance(response, web.Response)
        and response.content_type == "text/html"
        and response.body
    ):
        return response
    markup = response.text
    additions = []
    if request.path == "/":
        if _NETWORK_TRAFFIC_SCRIPT not in markup:
            additions.append(_NETWORK_TRAFFIC_SCRIPT)
        if _SERVICE_HIERARCHY_INTERACTIONS_SCRIPT not in markup:
            additions.append(_SERVICE_HIERARCHY_INTERACTIONS_SCRIPT)
    elif request.path in _DISCOVERY_PRESENTATION_PATHS:
        if _DISCOVERY_PRESENTATION_STYLESHEET not in markup:
            additions.append(_DISCOVERY_PRESENTATION_STYLESHEET)
        if request.path == "/settings/discover":
            if _DISCOVERY_COVERAGE_STYLESHEET not in markup:
                additions.append(_DISCOVERY_COVERAGE_STYLESHEET)
            if _DISCOVERY_COVERAGE_SCRIPT not in markup:
                additions.append(_DISCOVERY_COVERAGE_SCRIPT)
        if request.path == "/settings/quick-add" and _ENDPOINT_PREFILL_SCRIPT not in markup:
            additions.append(_ENDPOINT_PREFILL_SCRIPT)
    if additions and "</body>" in markup:
        response.text = markup.replace("</body>", "".join(additions) + "</body>")
    return response


async def asset(request):
    name = request.match_info["name"]
    content_type = _OVERRIDE_TYPES.get(name)
    if content_type is None:
        return await factory.asset(request)
    return web.Response(
        text=_override_resource(name).read_text(encoding="utf-8"),
        content_type=content_type,
        charset="utf-8",
        headers={"Cache-Control": "no-cache"},
    )


def install(app):
    app.middlewares.append(managed_ui_presentation)
    app.middlewares.append(factory.v22_settings_presentation)
    app.router.add_get("/", factory.dashboard)
    app.router.add_get("/modules", factory.modules)
    app.router.add_get("/api/v2/build", factory.build_identity)
    app.router.add_get("/static/icons/{name}", factory.service_icon)
    app.router.add_get("/static/{name}", asset)


__all__ = ["install"]
