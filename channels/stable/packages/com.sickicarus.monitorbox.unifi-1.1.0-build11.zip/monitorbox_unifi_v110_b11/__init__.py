from __future__ import annotations

from monitorbox.v2.plugin_api import IntegrationDefinition, ModuleManifest, PluginMetadata
from .adoption import UniFiCandidateAdoption
from .onboarding import UniFiIntegration
from .phase2_policy import UniFiPhase2RuntimeExecutor
from .runtime import MODULE_BUILD, MODULE_ID, MODULE_VERSION

_UNIFI_RUNTIME = UniFiPhase2RuntimeExecutor()
_UNIFI = UniFiIntegration()
_UNIFI_ADOPTION = UniFiCandidateAdoption()

PLUGIN = IntegrationDefinition(
    metadata=PluginMetadata(plugin_id="unifi", display_name="UniFi Network"),
    connection_kinds=("unifi",),
    runtime_adapter_kinds=("unifi",),
    discovery=_UNIFI,
    connection=_UNIFI,
    validation=_UNIFI,
    identity=_UNIFI,
    presentation=_UNIFI,
    runtime=_UNIFI,
    runtime_executor=_UNIFI_RUNTIME,
    candidate_adoption=_UNIFI_ADOPTION,
)

MODULE_MANIFEST = ModuleManifest(
    module_id=MODULE_ID,
    display_name="UniFi Network Integration",
    description='Monitors UniFi Network controller, device, and WAN health.',
    version=MODULE_VERSION,
    build=MODULE_BUILD,
    module_type="integration",
    entrypoints={"integration": "monitorbox_unifi_v110_b11:PLUGIN"},
    requires_core=">=2.4.0 <3.0.0",
    requires_runtime_api=">=1 <2",
    state_schema=1,
    publisher_id="com.sickicarus",
    capability_detection={'schema': 2, 'discovery_hints': {'schema': 1, 'tcp_ports': [443]}, 'matches': [{'id': 'unifi-https-port', 'confidence': 'possible', 'all': [{'fact': 'network.port', 'op': 'equals', 'value': '443'}]}]},
)

__all__ = [
    "MODULE_BUILD",
    "MODULE_ID",
    "MODULE_MANIFEST",
    "MODULE_VERSION",
    "PLUGIN",
    "UniFiCandidateAdoption",
    "UniFiIntegration",
    "UniFiPhase2RuntimeExecutor",
]
