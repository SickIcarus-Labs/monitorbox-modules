"""Managed MonitorBox UI build 2 adapter to the certified factory recovery seed."""

from monitorbox.v2.modules.ui import (
    MODULE_BUILD as FACTORY_BUILD,
    MODULE_ID as FACTORY_ID,
    MODULE_VERSION as FACTORY_VERSION,
    install as _factory_install,
)

_EXPECTED = ('com.sickicarus.monitorbox.ui', '1.0.0', 2)
if (FACTORY_ID, FACTORY_VERSION, FACTORY_BUILD) != _EXPECTED:
    raise ImportError(
        "managed UI build 2 requires the certified MonitorBox 2.3 factory UI build 2 seed"
    )


def install(app):
    _factory_install(app)


__all__ = ["install"]
