from __future__ import annotations

from monitorbox.v2.plugin_api import IntegrationDefinition, ModuleManifest, PluginMetadata

from ._base import HttpIntegration, MODULE_ID
from .startup_confirmation import HttpRuntimeExecutor

MODULE_VERSION = "1.1.0"
MODULE_BUILD = 3

_HTTP = HttpIntegration()
_EXECUTOR = HttpRuntimeExecutor()
PLUGIN = IntegrationDefinition(
    metadata=PluginMetadata(plugin_id="http", display_name="HTTP(S) endpoint"),
    connection_kinds=("http", "http_service"),
    runtime_adapter_kinds=("http",),
    discovery=_HTTP,
    connection=_HTTP,
    validation=_HTTP,
    identity=_HTTP,
    presentation=_HTTP,
    runtime=_HTTP,
    runtime_executor=_EXECUTOR,
)

MODULE_MANIFEST = ModuleManifest(
    module_id=MODULE_ID,
    display_name="HTTP(S) Integration",
    description='Monitors HTTP(S) endpoints and response health.',
    version=MODULE_VERSION,
    build=MODULE_BUILD,
    module_type="integration",
    entrypoints={"integration": "monitorbox_http_v110_b3:PLUGIN"},
    requires_core=">=2.4.0 <3.0.0",
    requires_runtime_api=">=1 <2",
    state_schema=1,
    publisher_id="com.sickicarus",
    capability_detection={'schema': 2, 'discovery_hints': {'schema': 1, 'tcp_ports': [80, 443, 8443, 9090]}, 'matches': [{'id': 'http-port-80', 'confidence': 'possible', 'all': [{'fact': 'network.port', 'op': 'equals', 'value': '80'}]}, {'id': 'http-port-443', 'confidence': 'possible', 'all': [{'fact': 'network.port', 'op': 'equals', 'value': '443'}]}, {'id': 'http-port-8443', 'confidence': 'possible', 'all': [{'fact': 'network.port', 'op': 'equals', 'value': '8443'}]}, {'id': 'http-port-9090', 'confidence': 'possible', 'all': [{'fact': 'network.port', 'op': 'equals', 'value': '9090'}]}]},
)

__all__ = ["HttpIntegration", "MODULE_BUILD", "MODULE_ID", "MODULE_MANIFEST", "MODULE_VERSION", "PLUGIN"]
