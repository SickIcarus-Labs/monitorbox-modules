"""Standalone managed MonitorBox UI 1.13.0 build 49.

Owns the complete normal UI after the Core factory implementation is retired.
"""

from __future__ import annotations

import re
from html import escape as html_escape
from importlib.resources import files

from aiohttp import web

from monitorbox.v2.build_info import current_build_identity


ASSETS = {
    "card-item-registry.js": "text/javascript",
    "card-composer-renderer.js": "text/javascript",
    "card-composer.css": "text/css",
    "dashboard-editor-tabs.js": "text/javascript",
    "dashboard-editor-tabs.css": "text/css",
    "card-layout-policy.js": "text/javascript",
    "card-layout.js": "text/javascript",
    "card-layout-editor.js": "text/javascript",
    "card-layout.css": "text/css",
    "card-projection.js": "text/javascript",
    "configuration-peer-navigation.js": "text/javascript",
    "configuration-peer-navigation.css": "text/css",
    "settings-shell.js": "text/javascript",
    "settings-shell.css": "text/css",
    "contextual-configuration.js": "text/javascript",
    "contextual-configuration.css": "text/css",
    "dashboard.css": "text/css",
    "service-presentation.css": "text/css",
    "v1-parity.css": "text/css",
    "v1-detail-parity.css": "text/css",
    "v1-beta-polish.css": "text/css",
    "v1-beta-hotfix.css": "text/css",
    "global-debug.css": "text/css",
    "v22-shell.css": "text/css",
    "modules.css": "text/css",
    "dashboard.js": "text/javascript",
    "conceptual-presentation.js": "text/javascript",
    "service-presentation.js": "text/javascript",
    "v1-parity.js": "text/javascript",
    "v1-detail-parity.js": "text/javascript",
    "v1-global-diagnostics.js": "text/javascript",
    "v1-beta-polish.js": "text/javascript",
    "v1-beta-hotfix.js": "text/javascript",
    "global-debug.js": "text/javascript",
    "operation-progress.js": "text/javascript",
    "live-ping.js": "text/javascript",
    "live-telemetry.js": "text/javascript",
    "dashboard-widgets.js": "text/javascript",
    "policy-ui.js": "text/javascript",
    "quick-add.js": "text/javascript",
    "v22-shell.js": "text/javascript",
    "workspace-state.js": "text/javascript",
    "workspace-finish.js": "text/javascript",
    "discovery-v22.js": "text/javascript",
    "advanced-v22-polish.js": "text/javascript",
    "advanced-dirty-state.js": "text/javascript",
    "http-v22-polish.js": "text/javascript",
    "settings-v22-shell.js": "text/javascript",
    "followup-beta-polish.js": "text/javascript",
    "onboarding-v22-acceptance.js": "text/javascript",
    "modules.js": "text/javascript",
    "endpoint-prefill-v22.js": "text/javascript",
    "discovery-presentation.css": "text/css",
    "discovery-coverage.js": "text/javascript",
    "discovery-coverage.css": "text/css",
    "network-traffic-presentation.js": "text/javascript",
    "service-hierarchy-interactions.js": "text/javascript",
    "service-hierarchy-physical-fixes.js": "text/javascript",
    "phase2-p1.js": "text/javascript",
    "phase2-physical-repairs.js": "text/javascript",
    "phase2-physical-repairs2.js": "text/javascript",
    "phase2-physical-repairs3.js": "text/javascript",
    "phase2-physical-repairs4.js": "text/javascript",
    "phase2-physical-repairs5.js": "text/javascript",
    "phase3-p1.js": "text/javascript",
    "phase3-p1.css": "text/css",
    "phase3-local-control.js": "text/javascript",
    "phase3-local-control.css": "text/css",
    "phase6-convergence.js": "text/javascript",
    "phase6-convergence.css": "text/css",
    "phase6-physical-convergence.js": "text/javascript",
    "phase6-physical-convergence.css": "text/css",
    "app-shell.css": "text/css",
    "app-shell.js": "text/javascript",
    "monitorbox-mark.svg": "image/svg+xml",
    "monitorbox-glyph.svg": "image/svg+xml",
    "monitorbox-192.png": "image/png",
    "monitorbox-512.png": "image/png",
    "monitorbox-apple-180.png": "image/png",
    "monitorbox-maskable-512.png": "image/png",
    "monitorbox.webmanifest": "application/manifest+json",
}
SERVICE_ICON_RE = re.compile(r"^[a-z0-9_-]+\.svg$")
_ADVANCED_POLISH_SCRIPT = '<script src="/static/advanced-v22-polish.js" defer></script>'
_ADVANCED_DIRTY_STATE_SCRIPT = '<script src="/static/advanced-dirty-state.js" defer></script>'
_PHASE6_CONVERGENCE_SCRIPT = '<script src="/static/phase6-convergence.js" defer></script>'
_PHASE6_CONVERGENCE_STYLE = '<link rel="stylesheet" href="/static/phase6-convergence.css">'
_PHASE6_PHYSICAL_SCRIPT = '<script src="/static/phase6-physical-convergence.js" defer></script>'
_PHASE6_PHYSICAL_STYLE = '<link rel="stylesheet" href="/static/phase6-physical-convergence.css">'
_HTTP_POLISH_SCRIPT = '<script src="/static/http-v22-polish.js" defer></script>'
_SETTINGS_SHELL_SCRIPT = '<script src="/static/settings-v22-shell.js" defer></script>'
_FOLLOWUP_BETA_POLISH_SCRIPT = '<script src="/static/followup-beta-polish.js" defer></script>'
_ONBOARDING_ACCEPTANCE_SCRIPT = '<script src="/static/onboarding-v22-acceptance.js" defer></script>'
_ENDPOINT_PREFILL_SCRIPT = '<script src="/static/endpoint-prefill-v22.js" defer></script>'
_DISCOVERY_PRESENTATION_STYLESHEET = '<link rel="stylesheet" href="/static/discovery-presentation.css">'
_DISCOVERY_COVERAGE_STYLESHEET = '<link rel="stylesheet" href="/static/discovery-coverage.css">'
_DISCOVERY_COVERAGE_SCRIPT = '<script src="/static/discovery-coverage.js" defer></script>'
_NETWORK_TRAFFIC_SCRIPT = '<script src="/static/network-traffic-presentation.js" defer></script>'
_SERVICE_HIERARCHY_INTERACTIONS_SCRIPT = '<script src="/static/service-hierarchy-interactions.js" defer></script>'
_SERVICE_HIERARCHY_PHYSICAL_SCRIPT = '<script src="/static/service-hierarchy-physical-fixes.js" defer></script>'
_PHASE2_P1_SCRIPT = '<script src="/static/phase2-p1.js" defer></script>'
_PHASE2_PHYSICAL_SCRIPT = '<script src="/static/phase2-physical-repairs.js" defer></script>'
_PHASE2_PHYSICAL2_SCRIPT = '<script src="/static/phase2-physical-repairs2.js" defer></script>'
_PHASE2_PHYSICAL3_SCRIPT = '<script src="/static/phase2-physical-repairs3.js" defer></script>'
_PHASE2_PHYSICAL4_SCRIPT = '<script src="/static/phase2-physical-repairs4.js" defer></script>'
_PHASE2_PHYSICAL5_SCRIPT = '<script src="/static/phase2-physical-repairs5.js" defer></script>'
_PHASE3_P1_SCRIPT = '<script src="/static/phase3-p1.js" defer></script>'
_PHASE3_DISCLOSURE_STYLE = '<link rel="stylesheet" href="/static/phase3-p1.css">'
_PHASE3_LOCAL_SCRIPT = '<script src="/static/phase3-local-control.js" defer></script>'
_PHASE3_LOCAL_STYLE = '<link rel="stylesheet" href="/static/phase3-local-control.css">'
_DISCOVERY_PRESENTATION_PATHS = frozenset(("/settings/quick-add", "/settings/discover"))


def _resource(name: str):
    return files(__package__).joinpath("assets", name)


def _service_icon_resource(name: str):
    if not SERVICE_ICON_RE.fullmatch(name):
        return None
    resource = files("monitorbox").joinpath("static", "icons", name)
    return resource if resource.is_file() else None


@web.middleware
async def v22_settings_presentation(request: web.Request, handler):
    response = await handler(request)
    if (
        isinstance(response, web.Response)
        and response.content_type == "text/html"
        and response.body
    ):
        markup = response.text
        scripts: list[str] = []
        if request.path == "/settings" or request.path.startswith("/settings/"):
            scripts.append(_FOLLOWUP_BETA_POLISH_SCRIPT)
        if request.path.startswith("/settings/"):
            scripts.append(_SETTINGS_SHELL_SCRIPT)
        if request.path == "/settings/advanced":
            scripts.extend((_ADVANCED_POLISH_SCRIPT, _ADVANCED_DIRTY_STATE_SCRIPT, _PHASE6_CONVERGENCE_STYLE, _PHASE6_CONVERGENCE_SCRIPT, _PHASE6_PHYSICAL_STYLE, _PHASE6_PHYSICAL_SCRIPT))
        elif request.path == "/settings/quick-add":
            scripts.append(_HTTP_POLISH_SCRIPT)
        if request.path in {
            "/settings/quick-add",
            "/settings/advanced/rerun-first-launch",
        }:
            scripts.append(_ONBOARDING_ACCEPTANCE_SCRIPT)
        if scripts and "</body>" in markup:
            missing = [script for script in scripts if script not in markup]
            if missing:
                response.text = markup.replace("</body>", "".join(missing) + "</body>")
    return response


@web.middleware
async def managed_ui_presentation(request: web.Request, handler):
    response = await handler(request)
    if not (
        isinstance(response, web.Response)
        and response.content_type == "text/html"
        and response.body
    ):
        return response
    markup = response.text
    additions: list[str] = []
    if request.path == "/":
        if _NETWORK_TRAFFIC_SCRIPT not in markup:
            additions.append(_NETWORK_TRAFFIC_SCRIPT)
        if _SERVICE_HIERARCHY_INTERACTIONS_SCRIPT not in markup:
            additions.append(_SERVICE_HIERARCHY_INTERACTIONS_SCRIPT)
        if _SERVICE_HIERARCHY_PHYSICAL_SCRIPT not in markup:
            additions.append(_SERVICE_HIERARCHY_PHYSICAL_SCRIPT)
    elif request.path in _DISCOVERY_PRESENTATION_PATHS:
        if _DISCOVERY_PRESENTATION_STYLESHEET not in markup:
            additions.append(_DISCOVERY_PRESENTATION_STYLESHEET)
        if request.path == "/settings/discover":
            if _DISCOVERY_COVERAGE_STYLESHEET not in markup:
                additions.append(_DISCOVERY_COVERAGE_STYLESHEET)
            if _DISCOVERY_COVERAGE_SCRIPT not in markup:
                additions.append(_DISCOVERY_COVERAGE_SCRIPT)
        if request.path == "/settings/quick-add" and _ENDPOINT_PREFILL_SCRIPT not in markup:
            additions.append(_ENDPOINT_PREFILL_SCRIPT)
    if request.path in {"/", "/settings/quick-add", "/settings/discover"} and _PHASE2_P1_SCRIPT not in markup:
        additions.append(_PHASE2_P1_SCRIPT)
    if request.path == "/settings/advanced" and _PHASE2_PHYSICAL_SCRIPT not in markup:
        additions.append(_PHASE2_PHYSICAL_SCRIPT)
    if request.path == "/settings/advanced" and _PHASE2_PHYSICAL2_SCRIPT not in markup:
        additions.append(_PHASE2_PHYSICAL2_SCRIPT)
    if request.path == "/settings/advanced" and _PHASE2_PHYSICAL3_SCRIPT not in markup:
        additions.append(_PHASE2_PHYSICAL3_SCRIPT)
    if request.path == "/" and _PHASE2_PHYSICAL5_SCRIPT not in markup:
        additions.append(_PHASE2_PHYSICAL5_SCRIPT)
    if request.path == "/" and _PHASE3_P1_SCRIPT not in markup:
        additions.append(_PHASE3_P1_SCRIPT)
    if request.path == "/" and _PHASE3_LOCAL_SCRIPT not in markup:
        additions.extend((_PHASE3_LOCAL_STYLE, _PHASE3_LOCAL_SCRIPT))
    if request.path == "/settings/discover" and _PHASE3_DISCLOSURE_STYLE not in markup:
        additions.append(_PHASE3_DISCLOSURE_STYLE)
    if additions and "</body>" in markup:
        response.text = markup.replace("</body>", "".join(additions) + "</body>")
    return response


@web.middleware
async def contextual_configuration_presentation(request: web.Request, handler):
    response = await handler(request)
    if not (
        request.path == "/"
        and isinstance(response, web.Response)
        and response.content_type == "text/html"
        and response.body
    ):
        return response
    markup = response.text
    style = '<link rel="stylesheet" href="/static/contextual-configuration.css">'
    script = '<script src="/static/contextual-configuration.js" defer></script>'
    additions = []
    if style not in markup:
        additions.append(style)
    if script not in markup:
        additions.append(script)
    if additions and "</body>" in markup:
        response.text = markup.replace("</body>", "".join(additions) + "</body>", 1)
    return response


_GLOBAL_DEBUG_STYLE = '<link rel="stylesheet" href="/static/global-debug.css?v=1.13.0-49">'
_GLOBAL_DEBUG_SCRIPT = '<script src="/static/global-debug.js?v=1.13.0-49" defer></script>'


def _has_element_id(markup: str, element_id: str) -> bool:
    return ('id="' + element_id + '"') in markup or ("id='" + element_id + "'") in markup


def _canonical_global_debug_fragments() -> tuple[str, str]:
    """Reuse the signed Dashboard's canonical Debug markup on every HTML surface."""
    dashboard_markup = _resource("dashboard.html").read_text(encoding="utf-8")

    toggle_start = dashboard_markup.find('<button id="debug-toggle"')
    toggle_end = dashboard_markup.find("</button>", toggle_start)
    console_start = dashboard_markup.find('<aside id="debug-console"')
    console_end = dashboard_markup.find("</aside>", console_start)
    if min(toggle_start, toggle_end, console_start, console_end) < 0:
        raise RuntimeError("canonical Dashboard Debug markup is incomplete")

    toggle_end += len("</button>")
    console_end += len("</aside>")
    return (
        dashboard_markup[toggle_start:toggle_end],
        dashboard_markup[console_start:console_end],
    )


@web.middleware
async def global_debug_presentation(request: web.Request, handler):
    response = await handler(request)
    if not (
        isinstance(response, web.Response)
        and response.content_type == "text/html"
        and response.body
    ):
        return response

    markup = response.text
    head_additions = []
    if _APP_SHELL_STYLE not in markup:
        head_additions.append(_APP_SHELL_STYLE)
    if _GLOBAL_DEBUG_STYLE not in markup:
        head_additions.append(_GLOBAL_DEBUG_STYLE)
    if head_additions and "</head>" in markup:
        markup = markup.replace("</head>", "".join(head_additions) + "</head>", 1)

    toggle, console = _canonical_global_debug_fragments()
    additions = []
    if not _has_element_id(markup, "debug-toggle"):
        additions.append(toggle)
    if not _has_element_id(markup, "debug-console"):
        additions.append(console)
    # Debug owns behavior. App-shell owns global shell composition and adopts the
    # exact canonical Debug node. Settings-shell only changes shell navigation.
    if _GLOBAL_DEBUG_SCRIPT not in markup:
        additions.append(_GLOBAL_DEBUG_SCRIPT)
    if _APP_SHELL_SCRIPT not in markup:
        additions.append(_APP_SHELL_SCRIPT)
    if additions and "</body>" in markup:
        markup = markup.replace("</body>", "".join(additions) + "</body>", 1)

    response.text = markup
    return response


@web.middleware
async def settings_shell_presentation(request: web.Request, handler):
    response = await handler(request)
    if not (
        isinstance(response, web.Response)
        and response.content_type == "text/html"
        and response.body
    ):
        return response
    markup = response.text
    style = '<link rel="stylesheet" href="/static/settings-shell.css?v=1.13.0-49">'
    script = '<script src="/static/settings-shell.js?v=1.13.0-49" defer></script>'
    additions = []
    if style not in markup:
        additions.append(style)
    if script not in markup:
        additions.append(script)
    if additions and "</body>" in markup:
        response.text = markup.replace("</body>", "".join(additions) + "</body>", 1)
    return response


_CONFIGURATION_PEER_STYLE = '<link rel="stylesheet" href="/static/configuration-peer-navigation.css?v=1.13.0-49">'
_CONFIGURATION_PEER_SCRIPT = '<script src="/static/configuration-peer-navigation.js?v=1.13.0-49" defer></script>'


@web.middleware
async def configuration_peer_navigation_presentation(request: web.Request, handler):
    response = await handler(request)
    if not (
        request.path.startswith("/settings")
        and isinstance(response, web.Response)
        and response.content_type == "text/html"
        and response.body
    ):
        return response

    markup = response.text
    additions = []
    if _CONFIGURATION_PEER_STYLE not in markup:
        additions.append(_CONFIGURATION_PEER_STYLE)
    if _CONFIGURATION_PEER_SCRIPT not in markup:
        additions.append(_CONFIGURATION_PEER_SCRIPT)
    if additions and "</body>" in markup:
        response.text = markup.replace("</body>", "".join(additions) + "</body>", 1)
    return response


async def dashboard_cards_page(_: web.Request) -> web.Response:
    return web.Response(
        text=_resource("card-layout-editor.html").read_text(encoding="utf-8"),
        content_type="text/html",
        charset="utf-8",
        headers={"Cache-Control": "no-store"},
    )


_DASHBOARD_EDITOR_TABS = (
    '<link rel="stylesheet" href="/static/dashboard-editor-tabs.css?v=1.13.0-49">'
    '<script src="/static/dashboard-editor-tabs.js?v=1.13.0-49" defer></script>'
)


@web.middleware
async def dashboard_editor_tabs_middleware(request: web.Request, handler):
    response = await handler(request)
    if (
        request.path != "/settings/dashboard"
        or not isinstance(response, web.Response)
        or response.content_type != "text/html"
        or not response.body
    ):
        return response
    markup = response.text
    if _DASHBOARD_EDITOR_TABS not in markup and "</body>" in markup:
        response.text = markup.replace("</body>", _DASHBOARD_EDITOR_TABS + "</body>", 1)
    return response


async def dashboard(_: web.Request) -> web.Response:
    identity = current_build_identity()
    markup = _resource("dashboard.html").read_text(encoding="utf-8")
    markup = markup.replace("__MONITORBOX_BUILD_LABEL__", html_escape(identity.display))
    return web.Response(
        text=markup,
        content_type="text/html",
        charset="utf-8",
        headers={"Cache-Control": "no-cache"},
    )


async def modules(_: web.Request) -> web.Response:
    identity = current_build_identity()
    markup = _resource("modules.html").read_text(encoding="utf-8")
    markup = markup.replace("__MONITORBOX_BUILD_LABEL__", html_escape(identity.display))
    return web.Response(
        text=markup,
        content_type="text/html",
        charset="utf-8",
        headers={"Cache-Control": "no-cache"},
    )


async def build_identity(_: web.Request) -> web.Response:
    return web.json_response(current_build_identity().as_dict())


_UI_GENERATION = "1.13.0-49"
_STATIC_REFERENCE_RE = re.compile(
    r'(?P<prefix>(?:src|href)=["\'])/static/(?P<name>[A-Za-z0-9._-]+)(?:\?[^"\']*)?(?P<suffix>["\'])'
)


def _version_managed_assets(markup: str) -> str:
    """Attach this exact UI generation to managed static references.

    HTML remains freshness-checked, while immutable generation URLs let browsers
    reuse coherent CSS/JS without a validation round-trip on every page navigation.
    """
    def replace(match: re.Match[str]) -> str:
        name = match.group("name")
        if name not in ASSETS:
            return match.group(0)
        return (
            f'{match.group("prefix")}/static/{name}?v={_UI_GENERATION}'
            f'{match.group("suffix")}'
        )

    return _STATIC_REFERENCE_RE.sub(replace, markup)


_APP_SHELL_STYLE = '<link rel="stylesheet" href="/static/app-shell.css?v=1.13.0-49">'
_APP_SHELL_SCRIPT = '<script src="/static/app-shell.js?v=1.13.0-49" defer></script>'
_APPLE_TOUCH_ICON = '<link rel="apple-touch-icon" sizes="180x180" href="/static/monitorbox-apple-180.png?v=1.13.0-49">'


def _uses_app_shell(path):
    return (
        path == "/"
        or path.startswith("/modules")
        or path.startswith("/settings")
        or path.startswith("/setup")
    )


@web.middleware
async def app_shell_presentation(request, handler):
    response = await handler(request)
    if (
        _uses_app_shell(request.path)
        and isinstance(response, web.Response)
        and response.content_type == "text/html"
        and response.body
    ):
        markup = response.text
        if _APP_SHELL_STYLE not in markup and "</head>" in markup:
            markup = markup.replace("</head>", _APP_SHELL_STYLE + _APPLE_TOUCH_ICON + "</head>", 1)
        if _APP_SHELL_SCRIPT not in markup and "</body>" in markup:
            markup = markup.replace("</body>", _APP_SHELL_SCRIPT + "</body>", 1)
        markup = _version_managed_assets(markup)
        response.text = markup
        response.headers["X-MonitorBox-UI-Generation"] = _UI_GENERATION
    return response

async def asset(request: web.Request) -> web.Response:
    name = request.match_info["name"]
    content_type = ASSETS.get(name)
    if content_type is None:
        raise web.HTTPNotFound()

    requested_generation = request.query.get("v")
    if requested_generation and requested_generation != _UI_GENERATION:
        # Stale HTML/BFCache references are redirected to the active generation instead
        # of receiving mismatched bytes or a transient 404 during an update boundary.
        raise web.HTTPTemporaryRedirect(
            location=f"/static/{name}?v={_UI_GENERATION}"
        )

    immutable = requested_generation == _UI_GENERATION
    headers = {
        "Cache-Control": (
            "public, max-age=31536000, immutable" if immutable else "no-cache"
        ),
        "X-MonitorBox-UI-Generation": _UI_GENERATION,
    }
    resource = _resource(name)
    if content_type == "image/png":
        return web.Response(
            body=resource.read_bytes(),
            content_type=content_type,
            headers=headers,
        )
    return web.Response(
        text=resource.read_text(encoding="utf-8"),
        content_type=content_type,
        charset="utf-8",
        headers=headers,
    )

async def service_icon(request: web.Request) -> web.Response:
    resource = _service_icon_resource(request.match_info["name"])
    if resource is None:
        raise web.HTTPNotFound()
    return web.Response(
        body=resource.read_bytes(),
        content_type="image/svg+xml",
        headers={"Cache-Control": "public, max-age=300"},
    )


def _require_card_projection_contract() -> None:
    import monitorbox.v2.presentation as core_presentation
    actual = getattr(core_presentation, 'CARD_PROJECTION_CONTRACT_VERSION', None)
    if actual != 1:
        raise RuntimeError('UI build40 requires Core dashboard-card projection contract v1; update Core using the Recovery page before enabling this UI')

def _automatic_layout_snapshot(app, document, current):
    """UI-owned capture of provider-neutral card defaults into opaque JSON.

    A live automatic homepage tracks new families; its last recorded default
    composition is committed to every configuration revision and is replayed
    unchanged after an exact snapshot restore. Core never parses these cards.
    """
    module_id = "com.sickicarus.monitorbox.ui"
    if current is not None:
        if current.get("schema_version") not in (1, 2, 3, 4):
            return current  # Unsupported future schema: never overwrite it.
        old_sites = current.get("data", {}).get("sites")
        if not isinstance(old_sites, dict):
            raise RuntimeError("Cannot reconcile an invalid saved UI layout")
        if module_id in document.get("metadata", {}).get("restored_preference_ids", []):
            return current  # Explicit snapshot restore pins recorded defaults.
    else:
        old_sites = {}

    source = app.get("monitorbox.public_state_snapshot")
    if not callable(source):
        # Existing customized layouts are still safe without a live state
        # source; a missing source may never fabricate a fresh auto snapshot.
        if current is not None and old_sites and all(
            row.get("mode") == "custom" for row in old_sites.values()
        ):
            return current
        raise RuntimeError("UI41 automatic snapshot needs Core public state provider")
    live = source()
    sites = live.get("sites") if isinstance(live, dict) else None
    if not isinstance(sites, list):
        raise RuntimeError("Core public site projection is unavailable")
    by_id = {row["id"]: row for row in sites
             if isinstance(row, dict) and isinstance(row.get("id"), str)}
    expected = [row["id"] for row in document.get("sites", [])
                if isinstance(row, dict) and isinstance(row.get("id"), str)]
    if any(site_id not in by_id for site_id in expected):
        raise RuntimeError("Cannot capture an automatic layout without every declared site")

    builtins = ("internet", "network", "cameras", "power")
    reserved = {"monitor", "monitorbox"}
    def slug(value, allowed):
        return (isinstance(value, str) and bool(value) and len(value) <= allowed
                and value[0] in "abcdefghijklmnopqrstuvwxyz"
                and all(char in "abcdefghijklmnopqrstuvwxyz0123456789_-"
                        for char in value))
    output = dict(old_sites)
    for site_id in expected:
        previous = old_sites.get(site_id)
        if previous is not None and previous.get("mode") == "custom":
            continue
        site = by_id[site_id]
        if not isinstance(site.get("cards"), list) or not isinstance(site.get("objects"), list):
            raise RuntimeError("Incomplete public card/host projection for "+site_id)
        host_ids, family_ids = [], set()
        for item in site["objects"]:
            if not isinstance(item, dict):
                continue
            object_id = item.get("id")
            if not slug(object_id, 63) or object_id in reserved or item.get("retired") is True:
                continue
            if item.get("explicit_front_page") is False:
                continue
            kind = item.get("kind")
            designated = (item.get("system_role") == "site_gateway" and
                          kind in ("host", "network_device"))
            explicit = kind == "host" and item.get("homepage_origin") == "operator"
            if designated or explicit:
                identifier = "host:"+object_id
                if identifier not in host_ids:
                    host_ids.append(identifier)
        for card in site["cards"]:
            if not isinstance(card, dict) or card.get("kind") != "dashboard_card":
                continue
            family = card.get("family") or card.get("id")
            if slug(family, 63) and family != "services":
                family_ids.add(family)
        ordered = [*host_ids,
                   *("family:"+family for family in builtins if family in family_ids),
                   *("family:"+family for family in sorted(family_ids.difference(builtins)))]
        if len(ordered) > 128:
            raise RuntimeError("Automatic dashboard exceeds 128 cards for "+site_id)
        output[site_id] = {
            "mode": "auto",
            "cards": [{"id": item, "visible": True} for item in ordered],
        }
    return {"schema_version": current["schema_version"] if current is not None else 3, "data": {"sites": output}}


def _require_opaque_preference_contract():
    try:
        from monitorbox.v2.module_preferences import (
            MODULE_PREFERENCES_CONTRACT_VERSION,
            MODULE_PREFERENCES_INITIALIZATION_CONTRACT_VERSION,
            register_preference_provider,
        )
    except ImportError as exc:
        raise RuntimeError(
            "UI build41 requires Core opaque preference initialization v2; update Core via Recovery"
        ) from exc
    if (MODULE_PREFERENCES_CONTRACT_VERSION != 1 or
            MODULE_PREFERENCES_INITIALIZATION_CONTRACT_VERSION != 2):
        raise RuntimeError(
            "UI build41 requires Core opaque preference initialization v2; update Core via Recovery"
        )
    return register_preference_provider


def install(app: web.Application) -> None:
    _require_card_projection_contract()
    register_provider = _require_opaque_preference_contract()
    register_provider(app, "com.sickicarus.monitorbox.ui", _automatic_layout_snapshot)
    app.router.add_get("/settings/cards", dashboard_cards_page)
    app.middlewares.append(dashboard_editor_tabs_middleware)
    app.middlewares.append(configuration_peer_navigation_presentation)
    app.middlewares.append(settings_shell_presentation)
    app.middlewares.append(global_debug_presentation)
    app.middlewares.append(contextual_configuration_presentation)
    app.middlewares.append(app_shell_presentation)
    # aiohttp composes middlewares in reverse list order. Preserve the certified
    # managed-build-10 layering: managed presentation wraps the original v2.2 shell.
    app.middlewares.append(managed_ui_presentation)
    app.middlewares.append(v22_settings_presentation)
    app.router.add_get("/", dashboard)
    app.router.add_get("/modules", modules)
    app.router.add_get("/api/v2/build", build_identity)
    app.router.add_get("/static/icons/{name}", service_icon)
    app.router.add_get("/static/{name}", asset)


__all__ = ["install"]
