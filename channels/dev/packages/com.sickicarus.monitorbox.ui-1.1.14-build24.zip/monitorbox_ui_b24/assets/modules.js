(() => {
  "use strict";

  const MODULES_API = "/api/v2/modules";
  const CONFIG_STATUS_API = "/api/v2/config/status";
  const CONFIG_LOGIN_API = "/api/v2/config/auth/login";
  const CONFIG_SESSION_API = "/api/v2/config/session";
  const CHECK_UPDATES_API = "/api/v2/config/modules/check-updates";
  const UPDATE_ALL_API = "/api/v2/config/modules/update-all";
  const REPOSITORIES_API = "/api/v2/config/modules/repositories";
  const CSRF_HEADER = "X-MonitorBox-CSRF";

  const list = document.getElementById("modules-list");
  const repositories = document.getElementById("modules-repositories");
  const capabilities = document.getElementById("modules-capabilities");
  const status = document.getElementById("modules-status");
  const authState = document.getElementById("modules-auth-state");
  const loginForm = document.getElementById("modules-login-form");
  const password = document.getElementById("modules-password");
  const checkUpdates = document.getElementById("modules-check-updates");
  const updateAll = document.getElementById("modules-update-all");
  const repositoryForm = document.getElementById("modules-repository-form");
  const repositoryId = document.getElementById("modules-repository-id");
  const repositoryName = document.getElementById("modules-repository-name");
  const repositoryUrl = document.getElementById("modules-repository-url");
  const repositoryKeyId = document.getElementById("modules-repository-key-id");
  const repositoryPublicKey = document.getElementById("modules-repository-public-key");
  const repositoryCredential = document.getElementById("modules-repository-credential");

  let model = null;
  let csrfToken = null;
  let authenticated = false;
  let busy = false;

  function text(value, fallback = "—") {
    if (value === null || value === undefined || value === "") return fallback;
    return String(value);
  }

  function setStatus(message, error = false) {
    status.textContent = message || "";
    status.classList.toggle("error", error);
  }

  async function jsonRequest(url, options = {}) {
    const response = await fetch(url, {
      credentials: "same-origin",
      cache: "no-store",
      ...options,
    });
    const contentType = response.headers.get("content-type") || "";
    const payload = contentType.includes("application/json")
      ? await response.json()
      : await response.text();
    if (!response.ok) {
      const message = typeof payload === "string"
        ? payload
        : payload && payload.error
          ? payload.error
          : `${response.status} ${response.statusText}`;
      throw new Error(message || `${response.status} ${response.statusText}`);
    }
    return payload;
  }

  function badge(label, className = "") {
    const item = document.createElement("span");
    item.className = `modules-badge ${className}`.trim();
    item.textContent = label;
    return item;
  }

  function detail(label, value) {
    const wrapper = document.createElement("div");
    const term = document.createElement("dt");
    const description = document.createElement("dd");
    term.textContent = label;
    description.textContent = text(value);
    wrapper.append(term, description);
    return wrapper;
  }

  function renderCapabilities() {
    const current = model && model.capabilities ? model.capabilities : {};
    const catalogRefresh = Boolean(current.catalog_refresh);
    const packageInstall = Boolean(current.package_install);
    const repositoryError = model && model.repository_error ? String(model.repository_error) : "";

    capabilities.replaceChildren();
    const heading = document.createElement("strong");
    if (repositoryError) {
      heading.textContent = "Module distribution unavailable";
    } else {
      heading.textContent = catalogRefresh && packageInstall
        ? "Repository and package operations ready"
        : "Module distribution is partially available";
    }
    const copy = document.createElement("span");
    if (repositoryError) {
      copy.textContent = ` ${repositoryError}`;
    } else {
      copy.textContent = catalogRefresh
        ? (packageInstall
          ? " Core reports repository refresh and trusted package installation available."
          : " Repository metadata can refresh, but trusted package installation is unavailable.")
        : (packageInstall
          ? " Repository refresh unavailable; trusted packages can be applied from the current cached catalog."
          : " Repository refresh unavailable; install/update remains disabled until a trusted package provider is configured.");
    }
    capabilities.append(heading, copy);
    capabilities.dataset.state = catalogRefresh && packageInstall && !repositoryError ? "ready" : "limited";

    checkUpdates.disabled = !catalogRefresh || !authenticated || !csrfToken || busy;
    checkUpdates.title = !catalogRefresh
      ? "Repository refresh unavailable"
      : (!authenticated || !csrfToken)
        ? "Administrator authentication required"
        : "Check configured module repositories for updates";

    const repositoryMutation = Boolean(current.repository_mutation);
    for (const control of repositoryForm.elements) {
      control.disabled = !repositoryMutation || !authenticated || !csrfToken || busy;
    }
    repositoryForm.title = !repositoryMutation
      ? "Repository mutation unavailable"
      : (!authenticated || !csrfToken)
        ? "Administrator authentication required"
        : "";
  }

  function repositoryMutationButton(repository, action) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "button secondary";
    button.textContent = action === "disable" ? "Disable" : "Enable";
    button.disabled = !authenticated || !csrfToken || busy;
    button.addEventListener("click", () => mutateRepository(repository, action));
    return button;
  }

  function renderRepositories() {
    repositories.replaceChildren();
    const items = model && Array.isArray(model.repositories) ? model.repositories : [];
    if (!items.length) {
      const empty = document.createElement("div");
      empty.className = "modules-empty";
      empty.textContent = "No module repositories are configured.";
      repositories.append(empty);
      return;
    }

    const enabled = items.filter(repository => repository.enabled);
    const healthy = !model?.repository_error && enabled.every(repository => repository.catalog_fetched_at);
    const summary = document.createElement("div");
    summary.className = "modules-repository-one-line";
    summary.textContent = healthy
      ? `Repositories enabled: ${enabled.map(repository => repository.display_name || repository.repository_id).join(", ") || "none"}`
      : `${enabled.length} of ${items.length} repositories enabled${model?.repository_error ? " · repository error" : ""}`;
    repositories.append(summary);

    const details = document.createElement("details");
    details.className = "modules-repository-details";
    const detailsSummary = document.createElement("summary");
    detailsSummary.textContent = "Repository details";
    const list = document.createElement("div");
    list.className = "modules-repository-summary";
    for (const repository of items) {
      const row = document.createElement("div");
      row.className = "modules-repository-row";
      row.dataset.repositoryId = text(repository.repository_id, "unknown");

      const identity = document.createElement("div");
      identity.className = "modules-repository-identity";
      const name = document.createElement("strong");
      name.textContent = text(repository.display_name, repository.repository_id);
      const meta = document.createElement("span");
      meta.className = "modules-meta";
      const state = repository.enabled ? "enabled" : "disabled";
      const authority = repository.official ? "official" : text(repository.repository_id);
      const catalog = repository.catalog_fetched_at ? "catalog ready" : "no cached catalog";
      meta.textContent = `${authority} · ${state} · ${catalog}`;
      identity.append(name, meta);

      const actions = document.createElement("div");
      actions.className = "modules-card-actions compact";
      for (const action of Array.isArray(repository.actions) ? repository.actions : []) {
        if (action === "enable" || action === "disable") {
          actions.append(repositoryMutationButton(repository, action));
        }
      }
      row.append(identity, actions);
      list.append(row);
    }
    details.append(detailsSummary, list);
    repositories.append(details);
  }

  function mutationButton(module, action) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = action === "remove" ? "button secondary" : "button";
    button.dataset.moduleAction = action;
    button.textContent = {
      install: "Install",
      update: "Update",
      rollback: "Roll Back",
      remove: "Remove",
    }[action] || action;
    button.disabled = !authenticated || !csrfToken || busy;
    button.addEventListener("click", () => mutateModule(module, action));
    return button;
  }

  function moduleSource(module, installed) {
    const record = installed ? module.installed : module.available;
    if (!record) return "—";
    const source = installed ? record.source_repository_id : record.repository_id;
    const channel = record.channel || record.release_channel || "";
    return channel ? `${text(source)} · ${channel}` : text(source);
  }

  function versionLabel(record) {
    if (!record) return "—";
    const version = text(record.version, "unknown").replace(/^v/i, "");
    return `v${version}`;
  }

  function exactVersion(record) {
    if (!record) return "—";
    return `${versionLabel(record)} · build ${text(record.build)}`;
  }

  function technicalDetails(module) {
    const detailsElement = document.createElement("details");
    detailsElement.className = "modules-technical";
    const summary = document.createElement("summary");
    summary.textContent = "Advanced / Diagnostics";
    const grid = document.createElement("dl");
    grid.className = "modules-grid modules-grid-technical";
    grid.append(
      detail("Module ID", module.module_id),
      detail("Installed artifact", module.installed ? module.installed.artifact_identity : null),
      detail("Installed digest", module.installed ? module.installed.digest_sha256 : null),
      detail("Installed source", module.installed ? module.installed.source_repository_id : null),
      detail("Previous artifact", module.previous ? module.previous.artifact_identity : null),
      detail("Available source", module.available ? module.available.repository_id : null),
      detail("Available digest", module.available ? module.available.digest_sha256 : null),
      detail("Available signing identity", module.available ? module.available.signature_identity : null),
      detail("Requires Core", module.installed?.requires_core || module.available?.requires_core),
      detail("Requires Module API", module.installed?.requires_runtime_api || module.available?.requires_runtime_api)
    );
    detailsElement.append(summary, grid);
    return detailsElement;
  }

  function lifecycleBadges(module) {
    const badges = document.createElement("div");
    badges.className = "modules-badges";
    if (module.installed) {
      const state = module.installed.lifecycle_state || (module.installed.enabled === false ? "disabled" : "installed");
      badges.append(badge(state));
      if (module.installed.lifecycle_policy === "required") badges.append(badge("required", "required"));
      if (module.available && module.available.update_available) badges.append(badge("update available", "update"));
    } else {
      badges.append(badge("available"));
    }
    return badges;
  }

  function renderModuleTile(module, installed) {
    const card = document.createElement("details");
    card.className = "modules-card modules-tile";
    card.dataset.moduleId = module.module_id;
    card.dataset.installed = installed ? "true" : "false";

    const summary = document.createElement("summary");
    summary.className = "modules-tile-summary";
    const identity = document.createElement("div");
    identity.className = "modules-tile-identity";
    const name = document.createElement("strong");
    name.textContent = text(module.display_name, module.module_id);
    const release = document.createElement("span");
    release.className = "modules-release";
    release.textContent = installed ? exactVersion(module.installed) : versionLabel(module.available);
    const source = document.createElement("span");
    source.className = "modules-meta";
    source.textContent = moduleSource(module, installed);
    identity.append(name, release, source);
    summary.append(identity, lifecycleBadges(module));

    const body = document.createElement("div");
    body.className = "modules-tile-body";
    const description = document.createElement("p");
    description.className = "modules-description";
    description.textContent = text(module.description, "No module description is published.");
    body.append(description);

    const releaseGrid = document.createElement("dl");
    releaseGrid.className = "modules-grid modules-grid-release";
    if (installed) {
      releaseGrid.append(
        detail("Installed", exactVersion(module.installed)),
        detail("Source / channel", moduleSource(module, true)),
        detail("Lifecycle", module.installed.lifecycle_policy || "optional")
      );
      if (module.available) {
        releaseGrid.append(
          detail("Available", exactVersion(module.available)),
          detail("Available source / channel", moduleSource(module, false))
        );
      }
    } else {
      releaseGrid.append(
        detail("Available", exactVersion(module.available)),
        detail("Source / channel", moduleSource(module, false))
      );
    }
    body.append(releaseGrid);

    const actions = document.createElement("div");
    actions.className = "modules-card-actions";
    const allowed = Array.isArray(module.actions) ? module.actions : [];
    if (!allowed.length) {
      const none = document.createElement("span");
      none.className = "modules-meta";
      none.textContent = installed && module.installed?.lifecycle_policy === "required"
        ? "Required module; Core policy currently authorizes no lifecycle action."
        : "Core currently authorizes no lifecycle action.";
      actions.append(none);
    } else {
      // Core is authoritative. Render every authorized action independently; presentation
      // must never infer or suppress lifecycle actions from update/lifecycle state.
      for (const action of allowed) actions.append(mutationButton(module, action));
    }
    body.append(actions, technicalDetails(module));
    card.append(summary, body);
    return card;
  }

  function renderModuleGroup(label, items, expanded) {
    const group = document.createElement("details");
    group.className = "modules-group";
    group.open = expanded;
    group.dataset.group = label.toLowerCase();
    const summary = document.createElement("summary");
    summary.className = "modules-group-summary";
    summary.textContent = `${label} Modules (${items.length})`;
    const body = document.createElement("div");
    body.className = "modules-group-body";
    if (!items.length) {
      const empty = document.createElement("div");
      empty.className = "modules-empty";
      empty.textContent = label === "Available"
        ? "No uninstalled compatible modules are available from the current catalogs."
        : "No modules are installed.";
      body.append(empty);
    } else {
      for (const module of items) body.append(renderModuleTile(module, label === "Installed"));
    }
    group.append(summary, body);
    return group;
  }

  function renderModules() {
    list.replaceChildren();
    const modules = model && Array.isArray(model.modules) ? model.modules : [];
    const installed = modules.filter(module => Boolean(module.installed));
    const installedIds = new Set(installed.map(module => module.module_id));
    const available = modules.filter(module => !installedIds.has(module.module_id) && Boolean(module.available));

    list.append(
      renderModuleGroup("Installed", installed, true),
      renderModuleGroup("Available", available, false)
    );

    const updates = installed.reduce(
      (count, module) => count + ((Array.isArray(module.actions) && module.actions.includes("update")) ? 1 : 0),
      0
    );
    const packageInstall = Boolean(model && model.capabilities && model.capabilities.package_install);
    updateAll.disabled = !authenticated || !csrfToken || !packageInstall || updates === 0 || busy;
    updateAll.textContent = updates > 0 ? `Update All (${updates})` : "Update All";
  }

  async function loadModel() {
    model = await jsonRequest(MODULES_API);
    renderCapabilities();
    renderRepositories();
    renderModules();
  }

  async function refreshSession() {
    const config = await jsonRequest(CONFIG_STATUS_API);
    authenticated = Boolean(config.authenticated);
    csrfToken = null;
    if (authenticated) {
      const session = await jsonRequest(CONFIG_SESSION_API);
      csrfToken = session.csrf_token || null;
      authState.textContent = `Authenticated as ${text(session.actor, "admin")}. Lifecycle writes are enabled.`;
      loginForm.hidden = true;
    } else {
      authState.textContent = "Authenticate with the existing MonitorBox configuration administrator to mutate module authority.";
      loginForm.hidden = false;
    }
    renderCapabilities();
    renderRepositories();
    renderModules();
  }

  async function mutateRepository(repository, action) {
    if (!authenticated || !csrfToken || busy) return;
    if (action === "disable" && !window.confirm(
      `Disable ${repository.display_name || repository.repository_id}? Installed modules remain available, but catalog discovery will stop.`
    )) return;

    busy = true;
    renderCapabilities();
    renderRepositories();
    renderModules();
    setStatus(`${action === "disable" ? "Disabling" : "Enabling"} ${repository.display_name || repository.repository_id}…`);
    try {
      const id = encodeURIComponent(repository.repository_id);
      await jsonRequest(`${REPOSITORIES_API}/${id}/${action}`, {
        method: "POST",
        headers: { [CSRF_HEADER]: csrfToken },
      });
      await loadModel();
      setStatus(`Repository ${action === "disable" ? "disabled" : "enabled"}.`);
    } catch (error) {
      setStatus(error.message || String(error), true);
    } finally {
      busy = false;
      renderCapabilities();
      renderRepositories();
      renderModules();
    }
  }

  async function mutateModule(module, action) {
    if (!authenticated || !csrfToken || busy) return;
    if ((action === "remove" || action === "rollback") && !window.confirm(
      `${action === "remove" ? "Remove" : "Roll back"} ${module.display_name || module.module_id}?`
    )) return;

    busy = true;
    renderCapabilities();
    renderRepositories();
    renderModules();
    setStatus(`${action} ${module.display_name || module.module_id}…`);
    try {
      const moduleId = encodeURIComponent(module.module_id);
      const payload = await jsonRequest(`/api/v2/config/modules/${moduleId}/${action}`, {
        method: "POST",
        headers: { [CSRF_HEADER]: csrfToken },
      });
      setStatus(
        payload.runtime_reconcile === "restart_scheduled"
          ? "Module authority committed. MonitorBox restart scheduled."
          : "Module authority committed. Runtime restart is required."
      );
      if (payload.runtime_reconcile !== "restart_scheduled") {
        await loadModel();
      }
    } catch (error) {
      setStatus(error.message || String(error), true);
    } finally {
      busy = false;
      renderCapabilities();
      renderRepositories();
      renderModules();
    }
  }

  async function updateAllModules() {
    if (!authenticated || !csrfToken || busy) return;
    busy = true;
    renderCapabilities();
    renderRepositories();
    renderModules();
    setStatus("Applying compatible cached module updates independently…");
    try {
      const payload = await jsonRequest(UPDATE_ALL_API, {
        method: "POST",
        headers: { [CSRF_HEADER]: csrfToken },
      });
      const summary = `${payload.updated || 0} updated, ${payload.failed || 0} failed.`;
      setStatus(
        payload.runtime_reconcile === "restart_scheduled"
          ? `${summary} Module authority committed; MonitorBox restart scheduled.`
          : summary,
        Boolean(payload.failed)
      );
      if (payload.runtime_reconcile !== "restart_scheduled") {
        await loadModel();
      }
    } catch (error) {
      setStatus(error.message || String(error), true);
    } finally {
      busy = false;
      renderCapabilities();
      renderRepositories();
      renderModules();
    }
  }

  repositoryForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!authenticated || !csrfToken || busy) return;
    busy = true;
    renderCapabilities();
    renderRepositories();
    renderModules();
    setStatus("Adding trusted module repository…");
    try {
      const credential = repositoryCredential.value.trim();
      const body = {
        repository_id: repositoryId.value.trim(),
        display_name: repositoryName.value.trim(),
        index_url: repositoryUrl.value.trim(),
        signature_identity: repositoryKeyId.value.trim(),
        public_key_base64: repositoryPublicKey.value.trim(),
      };
      if (credential) body.credential_handle = credential;
      await jsonRequest(REPOSITORIES_API, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          [CSRF_HEADER]: csrfToken,
        },
        body: JSON.stringify(body),
      });
      repositoryForm.reset();
      await loadModel();
      setStatus("Repository trust added. Check for updates to verify and cache its signed catalog.");
    } catch (error) {
      setStatus(error.message || String(error), true);
    } finally {
      busy = false;
      renderCapabilities();
      renderRepositories();
      renderModules();
    }
  });

  loginForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    setStatus("Authenticating…");
    try {
      await jsonRequest(CONFIG_LOGIN_API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password: password.value }),
      });
      password.value = "";
      await refreshSession();
      setStatus("Administrator session authenticated.");
    } catch (error) {
      setStatus(error.message || String(error), true);
    }
  });

  checkUpdates.addEventListener("click", async () => {
    if (!model || !model.capabilities || !model.capabilities.catalog_refresh) {
      setStatus("Repository refresh unavailable in this build; showing the current cached catalog.", true);
      return;
    }
    if (!authenticated || !csrfToken || busy) return;

    busy = true;
    renderCapabilities();
    renderRepositories();
    renderModules();
    setStatus("Checking configured module repositories for updates…");
    try {
      const payload = await jsonRequest(CHECK_UPDATES_API, {
        method: "POST",
        headers: { [CSRF_HEADER]: csrfToken },
      });
      await loadModel();
      const refreshed = Number(payload.refreshed || 0);
      const failed = Number(payload.failed || 0);
      setStatus(
        `Repository check complete: ${refreshed} refreshed, ${failed} failed.`,
        failed > 0
      );
    } catch (error) {
      setStatus(error.message || String(error), true);
    } finally {
      busy = false;
      renderCapabilities();
      renderRepositories();
      renderModules();
    }
  });

  updateAll.addEventListener("click", updateAllModules);

  Promise.all([loadModel(), refreshSession()]).catch((error) => {
    setStatus(error.message || String(error), true);
  });
})();