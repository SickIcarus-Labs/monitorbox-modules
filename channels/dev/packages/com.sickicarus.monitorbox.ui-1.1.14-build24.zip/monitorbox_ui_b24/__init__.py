"""Standalone managed MonitorBox UI 1.1.14 build 24.

Owns the complete normal UI after the Core factory implementation is retired.
"""

from __future__ import annotations

import re
from html import escape as html_escape
from importlib.resources import files

from aiohttp import web

from monitorbox.v2.build_info import current_build_identity


ASSETS = {
    "dashboard.css": "text/css",
    "service-presentation.css": "text/css",
    "v1-parity.css": "text/css",
    "v1-detail-parity.css": "text/css",
    "v1-beta-polish.css": "text/css",
    "v1-beta-hotfix.css": "text/css",
    "global-debug.css": "text/css",
    "v22-shell.css": "text/css",
    "modules.css": "text/css",
    "dashboard.js": "text/javascript",
    "conceptual-presentation.js": "text/javascript",
    "service-presentation.js": "text/javascript",
    "v1-parity.js": "text/javascript",
    "v1-detail-parity.js": "text/javascript",
    "v1-global-diagnostics.js": "text/javascript",
    "v1-beta-polish.js": "text/javascript",
    "v1-beta-hotfix.js": "text/javascript",
    "global-debug.js": "text/javascript",
    "operation-progress.js": "text/javascript",
    "live-ping.js": "text/javascript",
    "live-telemetry.js": "text/javascript",
    "dashboard-widgets.js": "text/javascript",
    "policy-ui.js": "text/javascript",
    "quick-add.js": "text/javascript",
    "v22-shell.js": "text/javascript",
    "workspace-state.js": "text/javascript",
    "workspace-finish.js": "text/javascript",
    "discovery-v22.js": "text/javascript",
    "advanced-v22-polish.js": "text/javascript",
    "advanced-dirty-state.js": "text/javascript",
    "http-v22-polish.js": "text/javascript",
    "settings-v22-shell.js": "text/javascript",
    "followup-beta-polish.js": "text/javascript",
    "onboarding-v22-acceptance.js": "text/javascript",
    "modules.js": "text/javascript",
    "endpoint-prefill-v22.js": "text/javascript",
    "discovery-presentation.css": "text/css",
    "discovery-coverage.js": "text/javascript",
    "discovery-coverage.css": "text/css",
    "network-traffic-presentation.js": "text/javascript",
    "service-hierarchy-interactions.js": "text/javascript",
    "service-hierarchy-physical-fixes.js": "text/javascript",
    "phase2-p1.js": "text/javascript",
    "phase2-physical-repairs.js": "text/javascript",
    "phase2-physical-repairs2.js": "text/javascript",
    "phase2-physical-repairs3.js": "text/javascript",
    "phase2-physical-repairs4.js": "text/javascript",
    "phase2-physical-repairs5.js": "text/javascript",
    "phase3-p1.js": "text/javascript",
    "phase3-p1.css": "text/css",
    "phase3-local-control.js": "text/javascript",
    "phase3-local-control.css": "text/css",
    "phase6-convergence.js": "text/javascript",
    "phase6-convergence.css": "text/css",
    "phase6-physical-convergence.js": "text/javascript",
    "phase6-physical-convergence.css": "text/css",
    "app-shell.css": "text/css",
    "app-shell.js": "text/javascript",
    "monitorbox-mark.svg": "image/svg+xml",
    "monitorbox-glyph.svg": "image/svg+xml",
    "monitorbox-192.png": "image/png",
    "monitorbox-512.png": "image/png",
    "monitorbox-apple-180.png": "image/png",
    "monitorbox-maskable-512.png": "image/png",
    "monitorbox.webmanifest": "application/manifest+json",
}
SERVICE_ICON_RE = re.compile(r"^[a-z0-9_-]+\.svg$")
_ADVANCED_POLISH_SCRIPT = '<script src="/static/advanced-v22-polish.js" defer></script>'
_ADVANCED_DIRTY_STATE_SCRIPT = '<script src="/static/advanced-dirty-state.js" defer></script>'
_PHASE6_CONVERGENCE_SCRIPT = '<script src="/static/phase6-convergence.js" defer></script>'
_PHASE6_CONVERGENCE_STYLE = '<link rel="stylesheet" href="/static/phase6-convergence.css">'
_PHASE6_PHYSICAL_SCRIPT = '<script src="/static/phase6-physical-convergence.js" defer></script>'
_PHASE6_PHYSICAL_STYLE = '<link rel="stylesheet" href="/static/phase6-physical-convergence.css">'
_HTTP_POLISH_SCRIPT = '<script src="/static/http-v22-polish.js" defer></script>'
_SETTINGS_SHELL_SCRIPT = '<script src="/static/settings-v22-shell.js" defer></script>'
_FOLLOWUP_BETA_POLISH_SCRIPT = '<script src="/static/followup-beta-polish.js" defer></script>'
_ONBOARDING_ACCEPTANCE_SCRIPT = '<script src="/static/onboarding-v22-acceptance.js" defer></script>'
_ENDPOINT_PREFILL_SCRIPT = '<script src="/static/endpoint-prefill-v22.js" defer></script>'
_DISCOVERY_PRESENTATION_STYLESHEET = '<link rel="stylesheet" href="/static/discovery-presentation.css">'
_DISCOVERY_COVERAGE_STYLESHEET = '<link rel="stylesheet" href="/static/discovery-coverage.css">'
_DISCOVERY_COVERAGE_SCRIPT = '<script src="/static/discovery-coverage.js" defer></script>'
_NETWORK_TRAFFIC_SCRIPT = '<script src="/static/network-traffic-presentation.js" defer></script>'
_SERVICE_HIERARCHY_INTERACTIONS_SCRIPT = '<script src="/static/service-hierarchy-interactions.js" defer></script>'
_SERVICE_HIERARCHY_PHYSICAL_SCRIPT = '<script src="/static/service-hierarchy-physical-fixes.js" defer></script>'
_PHASE2_P1_SCRIPT = '<script src="/static/phase2-p1.js" defer></script>'
_PHASE2_PHYSICAL_SCRIPT = '<script src="/static/phase2-physical-repairs.js" defer></script>'
_PHASE2_PHYSICAL2_SCRIPT = '<script src="/static/phase2-physical-repairs2.js" defer></script>'
_PHASE2_PHYSICAL3_SCRIPT = '<script src="/static/phase2-physical-repairs3.js" defer></script>'
_PHASE2_PHYSICAL4_SCRIPT = '<script src="/static/phase2-physical-repairs4.js" defer></script>'
_PHASE2_PHYSICAL5_SCRIPT = '<script src="/static/phase2-physical-repairs5.js" defer></script>'
_PHASE3_P1_SCRIPT = '<script src="/static/phase3-p1.js" defer></script>'
_PHASE3_DISCLOSURE_STYLE = '<link rel="stylesheet" href="/static/phase3-p1.css">'
_PHASE3_LOCAL_SCRIPT = '<script src="/static/phase3-local-control.js" defer></script>'
_PHASE3_LOCAL_STYLE = '<link rel="stylesheet" href="/static/phase3-local-control.css">'
_DISCOVERY_PRESENTATION_PATHS = frozenset(("/settings/quick-add", "/settings/discover"))


def _resource(name: str):
    return files(__package__).joinpath("assets", name)


def _service_icon_resource(name: str):
    if not SERVICE_ICON_RE.fullmatch(name):
        return None
    resource = files("monitorbox").joinpath("static", "icons", name)
    return resource if resource.is_file() else None


@web.middleware
async def v22_settings_presentation(request: web.Request, handler):
    response = await handler(request)
    if (
        isinstance(response, web.Response)
        and response.content_type == "text/html"
        and response.body
    ):
        markup = response.text
        scripts: list[str] = []
        if request.path == "/settings" or request.path.startswith("/settings/"):
            scripts.append(_FOLLOWUP_BETA_POLISH_SCRIPT)
        if request.path.startswith("/settings/"):
            scripts.append(_SETTINGS_SHELL_SCRIPT)
        if request.path == "/settings/advanced":
            scripts.extend((_ADVANCED_POLISH_SCRIPT, _ADVANCED_DIRTY_STATE_SCRIPT, _PHASE6_CONVERGENCE_STYLE, _PHASE6_CONVERGENCE_SCRIPT, _PHASE6_PHYSICAL_STYLE, _PHASE6_PHYSICAL_SCRIPT))
        elif request.path == "/settings/quick-add":
            scripts.append(_HTTP_POLISH_SCRIPT)
        if request.path in {
            "/settings/quick-add",
            "/settings/advanced/rerun-first-launch",
        }:
            scripts.append(_ONBOARDING_ACCEPTANCE_SCRIPT)
        if scripts and "</body>" in markup:
            missing = [script for script in scripts if script not in markup]
            if missing:
                response.text = markup.replace("</body>", "".join(missing) + "</body>")
    return response


@web.middleware
async def managed_ui_presentation(request: web.Request, handler):
    response = await handler(request)
    if not (
        isinstance(response, web.Response)
        and response.content_type == "text/html"
        and response.body
    ):
        return response
    markup = response.text
    additions: list[str] = []
    if request.path == "/":
        if _NETWORK_TRAFFIC_SCRIPT not in markup:
            additions.append(_NETWORK_TRAFFIC_SCRIPT)
        if _SERVICE_HIERARCHY_INTERACTIONS_SCRIPT not in markup:
            additions.append(_SERVICE_HIERARCHY_INTERACTIONS_SCRIPT)
        if _SERVICE_HIERARCHY_PHYSICAL_SCRIPT not in markup:
            additions.append(_SERVICE_HIERARCHY_PHYSICAL_SCRIPT)
    elif request.path in _DISCOVERY_PRESENTATION_PATHS:
        if _DISCOVERY_PRESENTATION_STYLESHEET not in markup:
            additions.append(_DISCOVERY_PRESENTATION_STYLESHEET)
        if request.path == "/settings/discover":
            if _DISCOVERY_COVERAGE_STYLESHEET not in markup:
                additions.append(_DISCOVERY_COVERAGE_STYLESHEET)
            if _DISCOVERY_COVERAGE_SCRIPT not in markup:
                additions.append(_DISCOVERY_COVERAGE_SCRIPT)
        if request.path == "/settings/quick-add" and _ENDPOINT_PREFILL_SCRIPT not in markup:
            additions.append(_ENDPOINT_PREFILL_SCRIPT)
    if request.path in {"/", "/settings/quick-add", "/settings/discover"} and _PHASE2_P1_SCRIPT not in markup:
        additions.append(_PHASE2_P1_SCRIPT)
    if request.path == "/settings/advanced" and _PHASE2_PHYSICAL_SCRIPT not in markup:
        additions.append(_PHASE2_PHYSICAL_SCRIPT)
    if request.path == "/settings/advanced" and _PHASE2_PHYSICAL2_SCRIPT not in markup:
        additions.append(_PHASE2_PHYSICAL2_SCRIPT)
    if request.path == "/settings/advanced" and _PHASE2_PHYSICAL3_SCRIPT not in markup:
        additions.append(_PHASE2_PHYSICAL3_SCRIPT)
    if request.path == "/" and _PHASE2_PHYSICAL5_SCRIPT not in markup:
        additions.append(_PHASE2_PHYSICAL5_SCRIPT)
    if request.path == "/" and _PHASE3_P1_SCRIPT not in markup:
        additions.append(_PHASE3_P1_SCRIPT)
    if request.path == "/" and _PHASE3_LOCAL_SCRIPT not in markup:
        additions.extend((_PHASE3_LOCAL_STYLE, _PHASE3_LOCAL_SCRIPT))
    if request.path == "/settings/discover" and _PHASE3_DISCLOSURE_STYLE not in markup:
        additions.append(_PHASE3_DISCLOSURE_STYLE)
    if additions and "</body>" in markup:
        response.text = markup.replace("</body>", "".join(additions) + "</body>")
    return response


async def dashboard(_: web.Request) -> web.Response:
    identity = current_build_identity()
    markup = _resource("dashboard.html").read_text(encoding="utf-8")
    markup = markup.replace("__MONITORBOX_BUILD_LABEL__", html_escape(identity.display))
    return web.Response(
        text=markup,
        content_type="text/html",
        charset="utf-8",
        headers={"Cache-Control": "no-cache"},
    )


async def modules(_: web.Request) -> web.Response:
    identity = current_build_identity()
    markup = _resource("modules.html").read_text(encoding="utf-8")
    markup = markup.replace("__MONITORBOX_BUILD_LABEL__", html_escape(identity.display))
    return web.Response(
        text=markup,
        content_type="text/html",
        charset="utf-8",
        headers={"Cache-Control": "no-cache"},
    )


async def build_identity(_: web.Request) -> web.Response:
    return web.json_response(current_build_identity().as_dict())


_APP_SHELL_STYLE = '<link rel="stylesheet" href="/static/app-shell.css?v=1.1.14-24">'
_APP_SHELL_SCRIPT = '<script src="/static/app-shell.js?v=1.1.14-24" defer></script>'
_APPLE_TOUCH_ICON = '<link rel="apple-touch-icon" sizes="180x180" href="/static/monitorbox-apple-180.png?v=1.1.14-24">'


def _uses_app_shell(path):
    return (
        path == "/"
        or path.startswith("/modules")
        or path.startswith("/settings")
        or path.startswith("/setup")
    )


@web.middleware
async def app_shell_presentation(request, handler):
    response = await handler(request)
    if (
        _uses_app_shell(request.path)
        and isinstance(response, web.Response)
        and response.content_type == "text/html"
        and response.body
    ):
        markup = response.text
        if _APP_SHELL_STYLE not in markup and "</head>" in markup:
            markup = markup.replace("</head>", _APP_SHELL_STYLE + _APPLE_TOUCH_ICON + "</head>", 1)
        if _APP_SHELL_SCRIPT not in markup and "</body>" in markup:
            markup = markup.replace("</body>", _APP_SHELL_SCRIPT + "</body>", 1)
        response.text = markup
    return response

async def asset(request: web.Request) -> web.Response:
    name = request.match_info["name"]
    content_type = ASSETS.get(name)
    if content_type is None:
        raise web.HTTPNotFound()
    resource = _resource(name)
    if content_type == "image/png":
        return web.Response(
            body=resource.read_bytes(),
            content_type=content_type,
            headers={"Cache-Control": "no-cache"},
        )
    return web.Response(
        text=resource.read_text(encoding="utf-8"),
        content_type=content_type,
        charset="utf-8",
        headers={"Cache-Control": "no-cache"},
    )


async def service_icon(request: web.Request) -> web.Response:
    resource = _service_icon_resource(request.match_info["name"])
    if resource is None:
        raise web.HTTPNotFound()
    return web.Response(
        body=resource.read_bytes(),
        content_type="image/svg+xml",
        headers={"Cache-Control": "public, max-age=300"},
    )


def install(app: web.Application) -> None:
    app.middlewares.append(app_shell_presentation)
    # aiohttp composes middlewares in reverse list order. Preserve the certified
    # managed-build-10 layering: managed presentation wraps the original v2.2 shell.
    app.middlewares.append(managed_ui_presentation)
    app.middlewares.append(v22_settings_presentation)
    app.router.add_get("/", dashboard)
    app.router.add_get("/modules", modules)
    app.router.add_get("/api/v2/build", build_identity)
    app.router.add_get("/static/icons/{name}", service_icon)
    app.router.add_get("/static/{name}", asset)


__all__ = ["install"]
