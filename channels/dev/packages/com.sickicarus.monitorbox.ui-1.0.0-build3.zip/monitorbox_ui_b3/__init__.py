"""Managed MonitorBox UI build 3 composed over the certified factory UI seed."""

from importlib.resources import files

from aiohttp import web
from monitorbox.v2.modules.ui import (
    MODULE_BUILD as FACTORY_BUILD,
    MODULE_ID as FACTORY_ID,
    MODULE_VERSION as FACTORY_VERSION,
)
from monitorbox.v2.modules.ui import application as factory

_EXPECTED = ('com.sickicarus.monitorbox.ui', '1.0.0', 2)
if (FACTORY_ID, FACTORY_VERSION, FACTORY_BUILD) != _EXPECTED:
    raise ImportError(
        "managed UI build 3 requires the certified MonitorBox 2.3 factory UI build 2 seed"
    )

_OVERRIDES = frozenset(("discovery-v22.js", "endpoint-prefill-v22.js"))
_ENDPOINT_PREFILL_SCRIPT = '<script src="/static/endpoint-prefill-v22.js" defer></script>'


def _override_resource(name):
    return files(__package__).joinpath("assets", name)


@web.middleware
async def endpoint_prefill_presentation(request, handler):
    response = await handler(request)
    if (
        request.path == "/settings/quick-add"
        and isinstance(response, web.Response)
        and response.content_type == "text/html"
        and response.body
    ):
        markup = response.text
        if _ENDPOINT_PREFILL_SCRIPT not in markup and "</body>" in markup:
            response.text = markup.replace(
                "</body>",
                _ENDPOINT_PREFILL_SCRIPT + "</body>",
            )
    return response


async def asset(request):
    name = request.match_info["name"]
    if name not in _OVERRIDES:
        return await factory.asset(request)
    return web.Response(
        text=_override_resource(name).read_text(encoding="utf-8"),
        content_type="text/javascript",
        charset="utf-8",
        headers={"Cache-Control": "no-cache"},
    )


def install(app):
    # Middleware order is intentional. aiohttp applies the list in reverse while
    # composing the handler, making this first middleware outermost. It therefore
    # appends endpoint-prefill after the factory presentation has injected its
    # existing deferred scripts, matching certified build-3 execution order.
    app.middlewares.append(endpoint_prefill_presentation)
    app.middlewares.append(factory.v22_settings_presentation)
    app.router.add_get("/", factory.dashboard)
    app.router.add_get("/modules", factory.modules)
    app.router.add_get("/api/v2/build", factory.build_identity)
    app.router.add_get("/static/icons/{name}", factory.service_icon)
    app.router.add_get("/static/{name}", asset)


__all__ = ["install"]
